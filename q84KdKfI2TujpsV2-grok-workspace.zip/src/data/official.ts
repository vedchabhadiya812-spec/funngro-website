/** Official Funngro destinations. Enrollment, OTP, and payouts happen there — not in this studio. */
export const official = {
  home: "https://www.funngro.com/",
  teen: "https://www.funngro.com/teen",
  earn: "https://funngro.com/earn",
  brands: "https://funngro.com/for-brands",
  faq: "https://funngro.com/faq",
  trust: "https://funngro.com/trust",
  about: "https://funngro.com/about",
  arcade: "https://funngro.com/arcade",
  play: "https://play.google.com/store/apps/details?id=com.wishbanc.funngro",
  ios: "https://apps.apple.com/in/app/funngro/id1579361075",
  brandsMail: "hello@funngro.com",
  safetyMail: "teenlancer@funngro.com",
} as const;

export const wallBrands = [
  "ICICI",
  "Kotak",
  "Paytm",
  "CarDekho",
  "Toluna",
  "Nielsen",
  "Mpokket",
  "Novio",
  "Lifelong",
  "LXME",
] as const;
