export type CategoryId =
  | "social"
  | "video"
  | "web"
  | "influencer"
  | "app"
  | "campus"
  | "research"
  | "data"
  | "voice"
  | "writing"
  | "design"
  | "promo";

export type ProjectKind = "Toffee" | "Company" | "Evaluation";

export type Project = {
  id: string;
  category: CategoryId;
  title: string;
  client: string;
  payLabel: string;
  payInr: number | null;
  minutes: number;
  where: string;
  kind: ProjectKind;
  summary: string;
  youBring: string;
  proof: string;
  skill: string;
};

export const categories: { id: CategoryId; label: string; line: string }[] = [
  { id: "social", label: "Social media", line: "Posts, stories, community replies" },
  { id: "video", label: "Video", line: "Reels, cutdowns, short edits" },
  { id: "web", label: "Web", line: "Pages, sections, simple builds" },
  { id: "influencer", label: "Influencer", line: "Share & Earn, authentic posts" },
  { id: "app", label: "App testing", line: "Install, walk flows, report bugs" },
  { id: "campus", label: "Campus", line: "Ambassador and on-ground work" },
  { id: "research", label: "Research", line: "Surveys, shelves, interviews" },
  { id: "data", label: "Data", line: "Sheets, tagging, clean entry" },
  { id: "voice", label: "Voice", line: "Short reads and explainers" },
  { id: "writing", label: "Writing", line: "Captions, blogs, product copy" },
  { id: "design", label: "Design", line: "Posters, decks, social frames" },
  { id: "promo", label: "Promotion", line: "Recall, sampling, referrals" },
];

export const projects: Project[] = [
  {
    id: "reels-d2c",
    category: "social",
    title: "Three reels for a D2C launch",
    client: "Skincare brand · sample brief",
    payLabel: "₹1,500",
    payInr: 1500,
    minutes: 180,
    where: "Remote",
    kind: "Company",
    summary: "Show the product in real light, with a hook in the first second. No stock-looking hands.",
    youBring: "A phone, decent daylight, and a point of view.",
    proof: "File links plus the live post URL.",
    skill: "Hooks, framing, and brand voice.",
  },
  {
    id: "stories",
    category: "social",
    title: "Five-frame story set",
    client: "Fintech learning app",
    payLabel: "₹850",
    payInr: 850,
    minutes: 90,
    where: "Remote",
    kind: "Company",
    summary: "A story sequence that explains one feature without sounding like an ad read.",
    youBring: "Canva or Instagram edits. Templates are fine if the copy is yours.",
    proof: "Exports and a screenshot of the story stickers.",
    skill: "Sequencing and plain-language copy.",
  },
  {
    id: "cutdown",
    category: "video",
    title: "Twenty-second product cutdown",
    client: "Mobility brand",
    payLabel: "₹2,200",
    payInr: 2200,
    minutes: 240,
    where: "Remote",
    kind: "Company",
    summary: "Trim a longer clip into a 20s cut with captions that can be read on mute.",
    youBring: "CapCut, VN, or similar. They supply the raw clip.",
    proof: "Final MP4, caption file, and a still.",
    skill: "Pacing and on-screen text.",
  },
  {
    id: "copy-pack",
    category: "writing",
    title: "Four product descriptions",
    client: "Home brand",
    payLabel: "₹1,200",
    payInr: 1200,
    minutes: 150,
    where: "Remote",
    kind: "Company",
    summary: "Write like a person who used the thing, not like a catalogue from 2009.",
    youBring: "Clear English or Hindi. Say which you write in.",
    proof: "Doc with four variants and the source notes.",
    skill: "Specificity. Benefits without fluff.",
  },
  {
    id: "posters",
    category: "design",
    title: "Festival poster trio",
    client: "Campus fest sponsor",
    payLabel: "₹1,800",
    payInr: 1800,
    minutes: 300,
    where: "Remote",
    kind: "Company",
    summary: "Three sizes: story, feed, and a WhatsApp forward. Same idea, different crops.",
    youBring: "Figma, Photoshop, or Canva Pro. Brand kit is provided.",
    proof: "Source file plus PNG exports.",
    skill: "Hierarchy and type that survives a phone screen.",
  },
  {
    id: "survey",
    category: "research",
    title: "Twelve-question category survey",
    client: "Research panel",
    payLabel: "₹250",
    payInr: 250,
    minutes: 20,
    where: "Remote",
    kind: "Toffee",
    summary: "A short opinion survey. Answer honestly. Speed-clicking gets rejected.",
    youBring: "Ten quiet minutes and a real opinion.",
    proof: "Completion code inside the app.",
    skill: "How researchers actually read answers.",
  },
  {
    id: "shelf",
    category: "research",
    title: "Competitor shelf notes",
    client: "Snack brand",
    payLabel: "₹900",
    payInr: 900,
    minutes: 120,
    where: "Your city · kirana or modern trade",
    kind: "Company",
    summary: "Photograph a shelf, note prices, and write what a teenager would actually pick.",
    youBring: "A store you can visit this week. Ask before you shoot if staff mind.",
    proof: "Photos, price list, five-line read.",
    skill: "Observation. The detail is the job.",
  },
  {
    id: "voice",
    category: "voice",
    title: "Thirty-second app explainer",
    client: "Edtech",
    payLabel: "₹1,000",
    payInr: 1000,
    minutes: 60,
    where: "Remote",
    kind: "Company",
    summary: "Read a script like you are texting a friend, not narrating a documentary.",
    youBring: "A quiet room and any phone mic. Headphones help you hear the hiss.",
    proof: "WAV or high-quality M4A, two takes.",
    skill: "Diction and pace.",
  },
  {
    id: "sheet",
    category: "data",
    title: "Clean 150 sheet rows",
    client: "Ops team",
    payLabel: "₹600",
    payInr: 600,
    minutes: 120,
    where: "Remote",
    kind: "Toffee",
    summary: "Fix names, cities, and duplicates against a written rule sheet.",
    youBring: "Google Sheets. Patience counts more than speed.",
    proof: "Edited sheet plus a note of what you changed.",
    skill: "Accuracy under boring work. That is a skill.",
  },
  {
    id: "hero-web",
    category: "web",
    title: "One landing hero, built",
    client: "Early-stage startup",
    payLabel: "₹3,000",
    payInr: 3000,
    minutes: 480,
    where: "Remote",
    kind: "Company",
    summary: "Design and build a single hero section. Not a whole site. Mobile first.",
    youBring: "HTML/CSS or a no-code tool you can hand over.",
    proof: "Link, repo or file, and a phone screenshot.",
    skill: "Layout, type, and a headline that fits.",
  },
  {
    id: "bugbash",
    category: "app",
    title: "Walk eight flows, file the breaks",
    client: "Consumer app",
    payLabel: "₹500",
    payInr: 500,
    minutes: 45,
    where: "Remote",
    kind: "Toffee",
    summary: "Install a build, follow a script, and write bugs a developer can reproduce.",
    youBring: "Android or iPhone, and screenshots with steps.",
    proof: "Bug list: what you did, what you expected, what happened.",
    skill: "Repro steps. 'It crashed' is not a report.",
  },
  {
    id: "sampling",
    category: "campus",
    title: "Saturday sampling, one college",
    client: "Beverage brand",
    payLabel: "₹1,000",
    payInr: 1000,
    minutes: 240,
    where: "On campus · selected cities",
    kind: "Company",
    summary: "Hand samples, collect first reactions, and don't invent quotes.",
    youBring: "Permission to be on campus and a parent nod if you are under 18.",
    proof: "Count sheet, three photos, ten verbatim lines.",
    skill: "Talking to strangers without a script glued to your face.",
  },
  {
    id: "earnify",
    category: "influencer",
    title: "Share & Earn brief",
    client: "App install campaign",
    payLabel: "Per verified action",
    payInr: null,
    minutes: 40,
    where: "Remote",
    kind: "Company",
    summary: "Share a tracked link with people who would actually use it. Followers are not the metric. Verified actions are.",
    youBring: "A real circle: class group, society, or niche page. No bought audiences.",
    proof: "The app tracks the action. You don't submit fake screenshots.",
    skill: "Trust. People click because you were specific.",
  },
  {
    id: "recall",
    category: "promo",
    title: "Brand-recall posts",
    client: "National FMCG",
    payLabel: "₹700",
    payInr: 700,
    minutes: 70,
    where: "Remote",
    kind: "Company",
    summary: "Two posts that mention the brand in a sentence you would actually say.",
    youBring: "Your own accounts. The brief lists banned claims.",
    proof: "Live URLs kept up for the window they set.",
    skill: "Saying the brand name without cringing.",
  },
  {
    id: "eval",
    category: "video",
    title: "Evaluation reel",
    client: "Funngro starter track",
    payLabel: "Starter",
    payInr: 300,
    minutes: 70,
    where: "Remote",
    kind: "Evaluation",
    summary: "A short paid trial. Public help pages describe evaluation projects as the step that shows you can finish work before bigger company briefs open up.",
    youBring: "Follow the brief exactly. This one is about reliability.",
    proof: "Upload inside the app, on time.",
    skill: "Reading a brief all the way through.",
  },
];

export const hourBands: Record<CategoryId, { low: number; high: number; note: string }> = {
  social: { low: 150, high: 400, note: "Reels pay more than a single story frame. Revisions change the hour." },
  video: { low: 200, high: 500, note: "Editing existing footage is faster than shooting." },
  web: { low: 250, high: 600, note: "A section is not a website. Scope is everything." },
  influencer: { low: 80, high: 300, note: "Share & Earn pays on verified actions, so quiet weeks pay less." },
  app: { low: 200, high: 450, note: "Testing is usually a fixed fee, not a day rate." },
  campus: { low: 120, high: 280, note: "On-ground hours include travel. Don't count travel as pure pay." },
  research: { low: 100, high: 250, note: "Surveys pay per good completion, not per hour you hoped." },
  data: { low: 80, high: 180, note: "Entry is steady and usually the floor, not the ceiling." },
  voice: { low: 200, high: 450, note: "Short reads. Long sessions are rare at the start." },
  writing: { low: 150, high: 350, note: "A tight product note beats a long blog nobody asked for." },
  design: { low: 180, high: 420, note: "Brand kits speed you up. Inventing a brand from zero does not." },
  promo: { low: 100, high: 260, note: "Promotion tasks are often fixed and quick." },
};

export function agePath(age: number) {
  if (age < 14) {
    return {
      title: "Company work is not open yet",
      tone: "wait" as const,
      points: [
        "Public FAQ: under 14, you can do household chores with parents, not paid company projects.",
        "Use the time to learn a tool — captions, Canva, a sheet — so 14 is not a cold start.",
        "Do not use a parent’s account to sneak into company work. That gets people removed.",
      ],
    };
  }
  if (age < 18) {
    return {
      title: "You can earn, with a parent in the loop",
      tone: "go" as const,
      points: [
        "14 and above: parental approval plus age proof, then you can work with real companies.",
        "Start with a Toffee task or an evaluation project so your first submission is small.",
        "Payouts go to a wallet, then UPI or bank. If the account is not in your name, sort that with a parent before you finish work — not after.",
      ],
    };
  }
  return {
    title: "Full earner path",
    tone: "go" as const,
    points: [
      "You can take company projects in the categories you actually have samples for.",
      "Groscore, repeat approvals, and a finished profile are what move you off starter tasks.",
      "Still free to join. A real brief will not ask you to pay to 'unlock' the wallet.",
    ],
  };
}

export const earnerFaq = [
  {
    q: "Who can join?",
    a: "Funngro is built for young Indians. Under 14, the public FAQ limits you to household chores with parents — not company projects. From 14, you need parental approval and age proof. Individual projects can add their own rules.",
  },
  {
    q: "Is there a fee?",
    a: "The public positioning is no investment to start. Wallet 'activation charges' in a random DM are not the product. Confirm anything money-related inside the official app.",
  },
  {
    q: "How do I get paid?",
    a: "Finish the task, submit proof, and wait for approval. Help pages describe an instant credit to the Funngro wallet after approval, then a withdrawal to UPI or a bank account.",
  },
  {
    q: "What is a Toffee project?",
    a: "A bite-sized task — often a survey, a short test, or a simple submission. Useful as a first completion. Company projects are larger briefs from brands. Evaluation projects are the starter proof that you can deliver.",
  },
  {
    q: "What is Groscore?",
    a: "A reliability score inside the app. On-time work, approvals, and a complete profile feed it. Public FAQ treats a stronger score as a way to see better projects. It is not a school mark, and this page cannot show your real one.",
  },
  {
    q: "What is Share & Earn?",
    a: "Also called Earnify in public FAQ. You share a tracked action — not a vague 'post and pray'. Pay follows verified actions. Bought followers don't help.",
  },
  {
    q: "What is a clan?",
    a: "A community of earners, often run by a clan leader. The company describes about a hundred clan leaders looking after large groups across India. It is a support layer, not a downline you pay to enter.",
  },
  {
    q: "Contests, spin, happy hour?",
    a: "They exist in the app as engagement on top of project pay. Treat them as optional and read the rules in the app. They are not a salary.",
  },
  {
    q: "Can I learn while I earn?",
    a: "That is the point of the teenlancer path: financial basics plus skill tracks, and an experience note you can show after approved work. One project will not make you a professional. Ten honest ones start to.",
  },
];

export const brandFaq = [
  {
    q: "What can we post?",
    a: "Promotion, sampling, referrals, content, surveys, influencer briefs, app tests, ideation, and light sales support. The useful unit is a verified action from someone who opted in — not another pile of impressions.",
  },
  {
    q: "Who shows up?",
    a: "Young Indians, described publicly as roughly 14–25, who joined to do paid work. They are not a rented celebrity list. Match the cohort to the city, age, and task.",
  },
  {
    q: "Can we pick people?",
    a: "The platform is built around matching on skills, interests, and project needs, then reviewing the work. You are not hiring a full-time team for a two-day brief.",
  },
  {
    q: "Is this only for big brands?",
    a: "No. Project-shaped work is often a better fit for startups and D2C teams than a permanent junior hire. You still need a clear brief, a fair fee, and someone to review submissions.",
  },
  {
    q: "What do we not get?",
    a: "A guarantee of virality. You get structured actions: a post that stayed up, a sample that was tried, a survey that was finished, a bug that can be reproduced.",
  },
];

export const brandWorks: {
  id: string;
  name: string;
  line: string;
  goodFor: string;
}[] = [
  { id: "promotion", name: "Brand promotion", line: "Recall and social posts checked at the action, not the impression.", goodFor: "Launches and category education." },
  { id: "sampling", name: "Sampling", line: "Real trials with a short reaction, in the right city and age.", goodFor: "FMCG, beauty, food." },
  { id: "referral", name: "Referrals", line: "Tracked shares into a circle that already trusts the sender.", goodFor: "Apps and student offers." },
  { id: "content", name: "Content", line: "Reels, copy, design crops made by the audience you are trying to reach.", goodFor: "Always-on social." },
  { id: "survey", name: "Surveys", line: "Opinions from people in the category, with bad-faith speed runs filtered.", goodFor: "Product and pricing questions." },
  { id: "influencer", name: "Influencer briefs", line: "Smaller, specific voices instead of one expensive face.", goodFor: "Campus and niche communities." },
  { id: "testing", name: "App testing", line: "Scripted flows and bug notes from first-time users.", goodFor: "Pre-launch builds." },
  { id: "ideation", name: "Ideation", line: "Concepts and naming from people who will ignore anything boring.", goodFor: "Early creative sprints." },
];

export const stories = [
  {
    name: "Sarthak",
    city: "Delhi",
    quote: "A hundred rejection emails. He stayed. The public story is that he ended up working with founders on the product itself.",
    figure: "₹3.9L+",
    note: "Community-reported total",
  },
  {
    name: "Anshika",
    city: "Haryana",
    quote: "She assumed earning apps were fake. The first real withdrawal is what changed her mind.",
    figure: "₹2.25L+",
    note: "Community-reported total",
  },
  {
    name: "Sayyam",
    city: "Surat",
    quote: "Unsure at the start. A live meeting shifted the path. He went on to lead clan leaders.",
    figure: "₹63K+",
    note: "Community-reported total",
  },
  {
    name: "Ashwani",
    city: "Delhi",
    quote: "He thought it was fake, then decided the mistake was his. The work was ordinary and the payout was not a screenshot.",
    figure: "₹66K+",
    note: "Community-reported total",
  },
];

export const timeline = [
  { when: "2022", text: "Funngro starts so young Indians can turn time online into income." },
  { when: "2023", text: "About one million users. The company says this stretch was referral growth, not an ad blitz." },
  { when: "FY25", text: "First profitable quarter, roughly 3 million users, and a top-10 education ranking on Google Play." },
  { when: "FY26", text: "70 lakh+ young earners, 5,000+ brands, 1,000+ live projects. Most months profitable." },
];

export const ladder = [
  {
    stage: "01 · Start",
    title: "First income",
    body: "Surveys, sampling, short posts. You learn what 'approved' means.",
    range: "₹1K–₹3K in a steady month",
  },
  {
    stage: "02 · Grow",
    title: "Repeat work",
    body: "Content, referrals, a clan, more than one brand that already trusts your submissions.",
    range: "₹3K–₹7K in a steady month",
  },
  {
    stage: "03 · Build",
    title: "A tiny practice",
    body: "You run a few briefs, maybe with friends. The skill is the asset. The payout is the proof.",
    range: "₹7K–₹15K+ when the work is there",
  },
];

export function inr(value: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(value);
}
