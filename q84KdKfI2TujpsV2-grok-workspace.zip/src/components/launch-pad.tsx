import { ExternalLink } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { categories, projects, type CategoryId, type Project } from "@/data/content";
import { official } from "@/data/official";
import { useToast } from "@/lib/use-toast";

type AgeBand = "under14" | "teen" | "adult";
type TimeBand = "quick" | "evening" | "weekend";
type Gear = "phone" | "canva" | "laptop" | "store";
type Style = "home" | "out" | "talk";
type Goal = "rupee" | "portfolio" | "learn";

type Answers = {
  age: AgeBand;
  time: TimeBand;
  gear: Gear;
  style: Style;
  goal: Goal;
};

const steps: {
  key: keyof Answers;
  prompt: string;
  options: { id: Answers[keyof Answers]; label: string; hint: string }[];
}[] = [
  {
    key: "age",
    prompt: "How old are you?",
    options: [
      { id: "under14", label: "Under 14", hint: "Company work is closed" },
      { id: "teen", label: "14–17", hint: "Parent plus age proof" },
      { id: "adult", label: "18–25", hint: "Full earner path" },
    ],
  },
  {
    key: "time",
    prompt: "How long can you give this week?",
    options: [
      { id: "quick", label: "Under 30 min", hint: "Surveys, tagging, short posts" },
      { id: "evening", label: "One evening", hint: "Stories, copy, a voice take" },
      { id: "weekend", label: "A weekend", hint: "A reel, a poster set, a page" },
    ],
  },
  {
    key: "gear",
    prompt: "What can you actually use?",
    options: [
      { id: "phone", label: "Just my phone", hint: "Enough for a first task" },
      { id: "canva", label: "Phone and Canva", hint: "Stories and posters" },
      { id: "laptop", label: "A laptop", hint: "Sheets, pages, longer edits" },
      { id: "store", label: "I can visit a store", hint: "Shelf notes, sampling" },
    ],
  },
  {
    key: "style",
    prompt: "Where do you want the work to happen?",
    options: [
      { id: "home", label: "Stay in", hint: "Remote only" },
      { id: "out", label: "I can go out", hint: "Campus or a shop" },
      { id: "talk", label: "I like talking", hint: "Voice, referrals, campus" },
    ],
  },
  {
    key: "goal",
    prompt: "What do you want from the first month?",
    options: [
      { id: "rupee", label: "A first rupee", hint: "Short, easy to finish" },
      { id: "portfolio", label: "Something to show", hint: "A named piece of work" },
      { id: "learn", label: "A skill", hint: "Practice before the big brief" },
    ],
  },
];

const proofChecks = [
  { id: "brief", label: "It follows the brief, not a vibe I preferred" },
  { id: "mine", label: "The photo, voice, or file is mine — not stock" },
  { id: "phone", label: "A stranger can read it on a phone" },
  { id: "time", label: "I can submit before the deadline" },
  { id: "lang", label: "The language matches what they asked" },
  { id: "inside", label: "I will not take payment outside the app" },
] as const;

const week = [
  { id: "dl", title: "Download", body: "Official app. OTP. No fee screen." },
  { id: "profile", title: "Interests", body: "City, skills, one honest sample." },
  { id: "parent", title: "Parent", body: "Under 18: approval and age proof." },
  { id: "toffee", title: "Toffee", body: "One short task. Finish it cleanly." },
  { id: "proof", title: "Proof", body: "Upload what they asked, nothing extra." },
  { id: "apply", title: "Company", body: "Apply only where your sample matches." },
  { id: "upi", title: "UPI", body: "Withdraw after approval, not before." },
] as const;

function categoriesFor(answers: Answers): Set<CategoryId> {
  const cats = new Set<CategoryId>();
  if (answers.time === "quick") {
    cats.add("research");
    cats.add("promo");
    cats.add("data");
    cats.add("influencer");
  }
  if (answers.time === "evening") {
    cats.add("social");
    cats.add("writing");
    cats.add("voice");
    cats.add("influencer");
  }
  if (answers.time === "weekend") {
    cats.add("video");
    cats.add("design");
    cats.add("web");
    cats.add("app");
  }
  if (answers.gear === "phone") {
    cats.add("social");
    cats.add("voice");
    cats.add("research");
  }
  if (answers.gear === "canva") {
    cats.add("design");
    cats.add("social");
  }
  if (answers.gear === "laptop") {
    cats.add("web");
    cats.add("data");
    cats.add("writing");
    cats.add("video");
  }
  if (answers.gear === "store" || answers.style === "out") {
    cats.add("research");
    cats.add("campus");
    cats.add("promo");
  }
  if (answers.style === "talk") {
    cats.add("voice");
    cats.add("influencer");
    cats.add("campus");
  }
  if (answers.style === "home") {
    cats.delete("campus");
  }
  return cats;
}

function recommend(answers: Answers): Project[] {
  const cats = categoriesFor(answers);
  let list = projects.filter((project) => cats.has(project.category));
  if (answers.age === "under14") list = [];
  if (answers.gear !== "store" && answers.style !== "out") {
    list = list.filter((project) => project.where === "Remote");
  }
  if (answers.goal === "rupee") {
    list = [...list].sort((a, b) => a.minutes - b.minutes || (a.payInr ?? 0) - (b.payInr ?? 0));
  } else if (answers.goal === "portfolio") {
    list = [...list].sort((a, b) => (b.payInr ?? 0) - (a.payInr ?? 0));
  } else {
    list = [...list].sort((a, b) => (a.kind === "Evaluation" ? -1 : 1) - (b.kind === "Evaluation" ? -1 : 1));
  }
  if (list.length < 3 && answers.age !== "under14") {
    const extra = projects.filter((project) => !list.some((item) => item.id === project.id) && project.where === "Remote");
    list = [...list, ...extra];
  }
  return list.slice(0, 3);
}

const emptyAnswers = {} as Partial<Answers>;

export function LaunchPad({ onPick }: { onPick: (id: string) => void }) {
  const { show } = useToast();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Partial<Answers>>(emptyAnswers);
  const [proof, setProof] = useState<string[]>(["brief", "mine", "inside"]);
  const [done, setDone] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("funngro-week");
      if (raw) {
        const parsed = JSON.parse(raw) as unknown;
        if (Array.isArray(parsed)) {
          setDone(parsed.filter((id): id is string => week.some((day) => day.id === id)));
        }
      }
    } catch {
      /* ignore */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("funngro-week", JSON.stringify(done));
  }, [done, hydrated]);

  const complete = steps.every((item) => answers[item.key]);
  const picks = useMemo(() => (complete ? recommend(answers as Answers) : []), [answers, complete]);
  const current = steps[step];
  const proofScore = proof.length;
  const readiness = Math.round(
    (complete ? 34 : (Object.keys(answers).length / steps.length) * 20) +
      (proofScore / proofChecks.length) * 33 +
      (done.length / week.length) * 33,
  );

  function choose(id: Answers[keyof Answers]) {
    if (!current) return;
    const next = { ...answers, [current.key]: id };
    setAnswers(next);
    if (step < steps.length - 1) setStep(step + 1);
  }

  function toggleProof(id: string) {
    setProof((currentIds) => (currentIds.includes(id) ? currentIds.filter((item) => item !== id) : [...currentIds, id]));
  }

  function toggleDay(id: string) {
    setDone((currentIds) => (currentIds.includes(id) ? currentIds.filter((item) => item !== id) : [...currentIds, id]));
  }

  const parentNote = [
    "I want to join Funngro, a free app (no joining fee) where young Indians do short paid tasks for real brands — surveys, posts, sampling, design — and withdraw to UPI after the work is approved.",
    "Their public rule: under 14, no company projects. From 14, a parent approves and age proof is required.",
    `Official site: ${official.home}`,
    `Android: ${official.play}`,
    `iPhone: ${official.ios}`,
    "This note was written in a guide. The account is created only on Funngro.",
  ].join("\n\n");

  async function copyNote() {
    try {
      await navigator.clipboard.writeText(parentNote);
      show("Parent note copied");
    } catch {
      show("Select the note and copy it");
    }
  }

  return (
    <section className="border-y border-line bg-panel/40" id="launch">
      <div className="mx-auto max-w-6xl px-5 py-16">
        <p className="text-xs font-bold tracking-[0.18em] text-coral uppercase">The part their site does not do</p>
        <div className="mt-3 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
          <h2 className="max-w-2xl font-display text-4xl leading-tight font-extrabold tracking-tight sm:text-5xl">
            Match a first brief. Then enroll on the real Funngro.
          </h2>
          <p className="max-w-sm text-sm leading-relaxed text-mute">
            Four tools the marketing site does not ship: a fit match, a proof check, a seven-day plan, and a note for a parent. Accounts still open only in their app.
          </p>
        </div>

        <div className="mt-8 grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
          <article className="rounded-card bg-cream p-5 text-ink sm:p-7">
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs font-bold tracking-[0.16em] text-ink/50 uppercase">Fit match</p>
              <p className="text-sm font-bold">
                {complete ? "Matched" : `${step + 1} / ${steps.length}`}
              </p>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-ink/10">
              <div
                className="h-full rounded-full bg-ink transition-[width] duration-300"
                style={{ width: `${complete ? 100 : (step / steps.length) * 100}%` }}
              />
            </div>

            {complete ? (
              <div>
                <h3 className="mt-5 font-display text-3xl font-extrabold tracking-tight">
                  {answers.age === "under14" ? "Learn now. Enroll for pay at 14." : "Start with one of these."}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-ink/70">
                  {answers.age === "under14"
                    ? "Funngro’s public FAQ keeps company projects closed under 14. Open the app with a parent so you know the rule, and use the time to practise a tool."
                    : answers.age === "teen"
                      ? "You can earn once a parent approves and age proof is in. These are sample briefs, not live jobs."
                      : "Sample briefs in the shape of live work. The real list is inside the app after you enroll."}
                </p>
                {picks.length > 0 ? (
                  <ul className="mt-5 grid gap-3">
                    {picks.map((project) => (
                      <li key={project.id}>
                        <button
                          type="button"
                          onClick={() => onPick(project.id)}
                          className="tap flex w-full items-center justify-between gap-3 rounded-2xl bg-cream-dim px-4 py-3 text-left"
                        >
                          <span>
                            <span className="block text-xs font-bold tracking-wide text-ink/50 uppercase">
                              {project.kind} · {categories.find((item) => item.id === project.category)?.label}
                            </span>
                            <span className="mt-1 block font-display text-lg font-extrabold">{project.title}</span>
                          </span>
                          <span className="shrink-0 text-sm font-extrabold">{project.payLabel}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : null}
                <div className="mt-5 flex flex-col gap-3 sm:flex-row">
                  <a
                    href={answers.age === "under14" ? official.faq : official.earn}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="tap inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-ink px-4 text-sm font-bold text-cream"
                  >
                    {answers.age === "under14" ? "Read the official age rule" : "Enroll on Funngro"}
                    <ExternalLink className="size-4" />
                  </a>
                  <button
                    type="button"
                    className="h-12 rounded-xl border border-ink/15 px-4 text-sm font-bold"
                    onClick={() => {
                      setAnswers({});
                      setStep(0);
                    }}
                  >
                    Match again
                  </button>
                </div>
              </div>
            ) : current ? (
              <div>
                <h3 className="mt-5 font-display text-3xl font-extrabold tracking-tight">{current.prompt}</h3>
                <div className="mt-5 grid gap-3 sm:grid-cols-2" role="group" aria-label={current.prompt}>
                  {current.options.map((option) => (
                    <button
                      key={option.id}
                      type="button"
                      onClick={() => choose(option.id)}
                      className="tap min-h-16 rounded-2xl border border-ink/10 bg-cream-dim px-4 py-3 text-left hover:border-ink"
                    >
                      <span className="block font-display text-lg font-extrabold">{option.label}</span>
                      <span className="mt-1 block text-sm text-ink/60">{option.hint}</span>
                    </button>
                  ))}
                </div>
                {step > 0 ? (
                  <button type="button" className="mt-4 h-11 text-sm font-bold" onClick={() => setStep((value) => value - 1)}>
                    Back
                  </button>
                ) : null}
              </div>
            ) : null}
          </article>

          <div className="grid gap-4">
            <article className="rounded-card border border-line bg-ink p-5">
              <div className="flex items-end justify-between gap-3">
                <div>
                  <p className="text-xs font-bold tracking-[0.16em] text-lime uppercase">Ready to enroll</p>
                  <p className="mt-1 font-display text-5xl font-extrabold text-lime">{readiness}</p>
                </div>
                <p className="max-w-40 text-right text-xs leading-relaxed text-mute">Match, proof, and the week plan. Not a Groscore.</p>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-panel">
                <div className="h-full rounded-full bg-lime" style={{ width: `${readiness}%` }} />
              </div>
              <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                <a
                  href={official.play}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="tap inline-flex h-11 flex-1 items-center justify-center rounded-xl bg-lime text-sm font-bold text-ink"
                >
                  Google Play
                </a>
                <a
                  href={official.ios}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="tap inline-flex h-11 flex-1 items-center justify-center rounded-xl border border-line text-sm font-bold"
                >
                  App Store
                </a>
              </div>
            </article>

            <article className="rounded-card border border-line p-5">
              <h3 className="font-display text-2xl font-extrabold">Proof lab</h3>
              <p className="mt-1 text-sm text-mute">Tick what your submission will actually include. Their site says “upload proof”. It never lets you rehearse.</p>
              <ul className="mt-3 grid gap-1">
                {proofChecks.map((item) => {
                  const on = proof.includes(item.id);
                  return (
                    <li key={item.id}>
                      <button
                        type="button"
                        aria-pressed={on}
                        onClick={() => toggleProof(item.id)}
                        className="flex min-h-11 w-full items-center gap-3 text-left text-sm font-semibold"
                      >
                        <span className={on ? "grid size-5 shrink-0 place-items-center rounded-md bg-lime text-xs font-extrabold text-ink" : "size-5 shrink-0 rounded-md border border-line"} />
                        {item.label}
                      </button>
                    </li>
                  );
                })}
              </ul>
              <p className="mt-3 text-sm font-bold text-cream">
                {proofScore === proofChecks.length
                  ? "This is what an approval looks like. Submit it in the app."
                  : proofScore >= 4
                    ? "Close. Fix the gaps before you upload."
                    : "This is how a first task gets rejected."}
              </p>
            </article>
          </div>
        </div>

        <div className="mt-4 grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
          <article className="rounded-card border border-line p-5">
            <h3 className="font-display text-2xl font-extrabold">Seven days. Saved on this phone.</h3>
            <ol className="mt-4 grid gap-2 sm:grid-cols-2">
              {week.map((day, index) => {
                const on = done.includes(day.id);
                return (
                  <li key={day.id}>
                    <button
                      type="button"
                      aria-pressed={on}
                      onClick={() => toggleDay(day.id)}
                      className={
                        on
                          ? "tap flex min-h-20 w-full gap-3 rounded-2xl bg-lime px-3 py-3 text-left text-ink"
                          : "tap flex min-h-20 w-full gap-3 rounded-2xl border border-line px-3 py-3 text-left"
                      }
                    >
                      <span className="font-display text-lg font-extrabold">0{index + 1}</span>
                      <span>
                        <span className="block font-bold">{day.title}</span>
                        <span className={on ? "mt-1 block text-sm text-ink/70" : "mt-1 block text-sm text-mute"}>{day.body}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ol>
          </article>

          <article className="rounded-card bg-cream p-5 text-ink">
            <h3 className="font-display text-2xl font-extrabold">A note you can send a parent</h3>
            <p className="mt-2 text-sm leading-relaxed text-ink/70">
              Funngro publishes the rules. This turns them into one message, so you are not asking for a download with no context.
            </p>
            <textarea
              readOnly
              value={parentNote}
              className="mt-4 h-40 w-full resize-none rounded-2xl border border-ink/10 bg-cream-dim p-3 text-sm leading-relaxed"
              aria-label="Note for a parent"
            />
            <div className="mt-3 flex flex-col gap-2 sm:flex-row">
              <button type="button" onClick={copyNote} className="tap h-12 rounded-xl bg-ink px-4 text-sm font-bold text-cream">
                Copy note
              </button>
              <a
                href={official.trust}
                target="_blank"
                rel="noreferrer noopener"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-ink/15 px-4 text-sm font-bold"
              >
                Safety page
                <ExternalLink className="size-4" />
              </a>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}
