import { Link } from "@tanstack/react-router";
import {
  AppWindow,
  BadgePercent,
  Clapperboard,
  ExternalLink,
  GraduationCap,
  Megaphone,
  Mic,
  PenLine,
  PenTool,
  Search,
  Share2,
  Smartphone,
  Table2,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { LaunchPad } from "@/components/launch-pad";
import {
  agePath,
  categories,
  earnerFaq,
  hourBands,
  inr,
  ladder,
  projects,
  stories,
  timeline,
  type CategoryId,
  type Project,
} from "@/data/content";
import { official, wallBrands } from "@/data/official";
import { usePrefersReducedMotion } from "@/lib/motion";
import { useToast } from "@/lib/use-toast";

const icons: Record<CategoryId, LucideIcon> = {
  social: Share2,
  video: Clapperboard,
  web: AppWindow,
  influencer: Megaphone,
  app: Smartphone,
  campus: GraduationCap,
  research: Search,
  data: Table2,
  voice: Mic,
  writing: PenLine,
  design: PenTool,
  promo: BadgePercent,
};

const lines = [
  "Discover a project that fits this week",
  "Build proof, not just a poster",
  "Withdraw approved earnings to UPI",
  "Start with a short Toffee task",
];

const barHeights = ["h-3", "h-5", "h-4", "h-8", "h-6", "h-10", "h-8", "h-12"] as const;

function CountUp({ to, suffix }: { to: number; suffix: string }) {
  const reduced = usePrefersReducedMotion();
  const [value, setValue] = useState(reduced ? to : 0);
  const [node, setNode] = useState<HTMLSpanElement | null>(null);

  useEffect(() => {
    if (!node) return;
    if (reduced) {
      setValue(to);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) return;
        observer.disconnect();
        const start = performance.now();
        const tick = (now: number) => {
          const progress = Math.min(1, (now - start) / 1100);
          const eased = 1 - (1 - progress) ** 3;
          setValue(Math.round(to * eased));
          if (progress < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      },
      { threshold: 0.6 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [node, reduced, to]);

  return (
    <span ref={setNode}>
      {value.toLocaleString("en-IN")}
      {suffix}
    </span>
  );
}

function WalletBars() {
  return (
    <div className="mt-4 flex h-12 items-end gap-1.5" aria-hidden="true">
      {barHeights.map((height, index) => (
        <span key={index} className={`flex-1 rounded-sm bg-ink/80 ${height}`} />
      ))}
    </div>
  );
}

export function TeenHome() {
  const reduced = usePrefersReducedMotion();
  const { message, show } = useToast();
  const [line, setLine] = useState(0);
  const [filter, setFilter] = useState<CategoryId | "all">("all");
  const [sort, setSort] = useState<"fit" | "pay" | "quick">("fit");
  const [activeId, setActiveId] = useState(projects[0]?.id ?? "");
  const [saved, setSaved] = useState<string[]>([]);
  const [name, setName] = useState("Aanya");
  const [age, setAge] = useState(16);
  const [hours, setHours] = useState(6);
  const [calcCat, setCalcCat] = useState<CategoryId>("social");
  const [habits, setHabits] = useState({ ontime: true, profile: true, clan: false, repeat: false });
  const [boardOpen, setBoardOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("funngro-studio");
      if (raw) {
        const parsed = JSON.parse(raw) as { name?: string; saved?: string[]; age?: number };
        if (typeof parsed.name === "string" && parsed.name.trim()) setName(parsed.name.slice(0, 32));
        if (Array.isArray(parsed.saved)) {
          setSaved(parsed.saved.filter((id) => projects.some((project) => project.id === id)));
        }
        if (typeof parsed.age === "number" && parsed.age >= 10 && parsed.age <= 25) setAge(parsed.age);
      }
    } catch {
      /* ignore broken local data */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("funngro-studio", JSON.stringify({ name, saved, age }));
  }, [hydrated, name, saved, age]);

  useEffect(() => {
    if (reduced) return;
    const timer = window.setInterval(() => setLine((index) => (index + 1) % lines.length), 2800);
    return () => window.clearInterval(timer);
  }, [reduced]);

  useEffect(() => {
    if (!boardOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setBoardOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [boardOpen]);

  const visible = useMemo(() => {
    const list = projects.filter((project) => filter === "all" || project.category === filter);
    const copy = [...list];
    if (sort === "pay") {
      copy.sort((a, b) => (b.payInr ?? -1) - (a.payInr ?? -1));
    } else if (sort === "quick") {
      copy.sort((a, b) => a.minutes - b.minutes);
    }
    return copy;
  }, [filter, sort]);

  useEffect(() => {
    if (!visible.some((project) => project.id === activeId) && visible[0]) {
      setActiveId(visible[0].id);
    }
  }, [visible, activeId]);

  const active = visible.find((project) => project.id === activeId) ?? visible[0] ?? projects[0];
  const path = agePath(age);
  const band = hourBands[calcCat];
  const low = hours * 4 * band.low;
  const high = hours * 4 * band.high;
  const score =
    420 +
    (habits.ontime ? 140 : 0) +
    (habits.profile ? 90 : 0) +
    (habits.clan ? 80 : 0) +
    (habits.repeat ? 120 : 0);
  const savedProjects = projects.filter((project) => saved.includes(project.id));
  const Icon = active ? icons[active.category] : Share2;

  function toggleSave(project: Project) {
    setSaved((current) => {
      const next = current.includes(project.id)
        ? current.filter((id) => id !== project.id)
        : [...current, project.id];
      return next;
    });
    show(saved.includes(project.id) ? "Removed from your board" : `Pinned “${project.title}”`);
  }

  return (
    <div>
      <section className="overflow-x-clip" id="top">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-12 lg:grid-cols-[1.1fr_0.9fr] lg:py-16">
          <div>
            <p className="reveal text-xs font-bold tracking-[0.18em] text-coral uppercase">
              Shark Tank India · Season 2 · SucSEED
            </p>
            <h1 className="reveal d1 mt-4 font-display text-5xl leading-[0.95] font-extrabold tracking-tight text-cream sm:text-6xl lg:text-7xl">
              Earn before 18.
              <span className="mt-2 block text-lime">With a brief, not a vibe.</span>
            </h1>
            <p className="reveal d2 mt-5 max-w-xl text-base leading-relaxed text-mute sm:text-lg">
              Funngro is the teenlancer path: young Indians take paid work from real brands — reels, surveys, sampling, design — then withdraw approved money to UPI. No joining fee.
            </p>
            <p className="reveal d2 mt-3 text-sm font-semibold text-cream" aria-live="polite">
              {lines[line]}
            </p>
            <div className="reveal d3 mt-7 flex flex-col gap-3 sm:flex-row">
              <a
                href={official.earn}
                target="_blank"
                rel="noreferrer noopener"
                className="tap inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-lime px-5 text-sm font-bold text-ink"
              >
                Enroll on Funngro
                <ExternalLink className="size-4" />
              </a>
              <a href="#launch" className="inline-flex h-12 items-center justify-center rounded-xl border border-line px-5 text-sm font-bold text-cream">
                Match me first
              </a>
            </div>
            <dl className="reveal d4 mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {[
                ["70", "L+", "Young Indians"],
                ["5,000", "+", "Brands"],
                ["1,000", "+", "Live projects"],
                ["12", "+", "Categories"],
              ].map(([num, suffix, label]) => (
                <div key={label}>
                  <dt className="font-display text-2xl font-extrabold text-cream">
                    {num === "70" || num === "12" ? (
                      <CountUp to={Number(num)} suffix={suffix ?? ""} />
                    ) : num === "5,000" ? (
                      <CountUp to={5000} suffix="+" />
                    ) : (
                      <CountUp to={1000} suffix="+" />
                    )}
                  </dt>
                  <dd className="mt-1 text-xs text-mute">{label}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative mx-auto w-full max-w-md">
            <article className="pass-notch relative rounded-card bg-cream p-6 text-ink shadow-[0_24px_60px_rgba(0,0,0,0.35)]">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-bold tracking-[0.16em] text-ink/60 uppercase">Gro Money · sample</p>
                  <p className="mt-2 font-display text-4xl font-extrabold tracking-tight">{inr(4280)}</p>
                  <p className="mt-1 text-sm text-ink/70">Illustrative month · not your balance</p>
                </div>
                <span className="rounded-full bg-coral px-3 py-1 text-xs font-bold text-cream">Live brief</span>
              </div>
              <WalletBars />
              <div className="mt-2 border-t border-dashed border-ink/15 pt-4">
                <p className="text-xs font-bold tracking-[0.14em] text-ink/50 uppercase">Matched for {name || "you"}</p>
                <ul className="mt-3 grid gap-2">
                  {(savedProjects.length ? savedProjects : projects).slice(0, 3).map((project) => (
                    <li key={project.id} className="flex items-center justify-between gap-3 rounded-xl bg-cream-dim px-3 py-2">
                      <span>
                        <span className="block text-sm font-bold">{project.title}</span>
                        <span className="text-xs text-ink/60">{project.where}</span>
                      </span>
                      <span className="text-sm font-extrabold">{project.payLabel}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          </div>
        </div>
      </section>

      <div className="border-y border-line overflow-hidden">
        <a
          href={official.home}
          target="_blank"
          rel="noreferrer noopener"
          className="block py-4"
          aria-label="Open Funngro’s live brand wall"
        >
          <div className="marquee gap-8 px-4 text-sm font-bold tracking-wide text-mute uppercase">
            {[...wallBrands, ...wallBrands].map((brand, index) => (
              <span key={`${brand}-${index}`} className="flex items-center gap-8">
                {brand}
                <span className="text-lime">/</span>
              </span>
            ))}
          </div>
        </a>
        <p className="px-5 pb-4 text-center text-xs text-mute">Names on Funngro’s public wall. The live list is on their site — this row opens it.</p>
      </div>

      <LaunchPad
        onPick={(id) => {
          setFilter("all");
          setSort("fit");
          setActiveId(id);
          document.getElementById("projects")?.scrollIntoView({ behavior: reduced ? "auto" : "smooth" });
        }}
      />

      <section className="mx-auto max-w-6xl px-5 py-16" id="how">
        <p className="text-xs font-bold tracking-[0.18em] text-lime uppercase">01 — The path</p>
        <h2 className="mt-3 max-w-xl font-display text-4xl leading-tight font-extrabold tracking-tight sm:text-5xl">
          From signup to a withdrawal you can explain.
        </h2>
        <ol className="mt-8 grid gap-4 md:grid-cols-5">
          {[
            ["Profile", "Interests, city, and a sample of what you can already do."],
            ["Age check", "Under 14 stays with parents. 14+ needs a parent and age proof."],
            ["First proof", "A Toffee task or an evaluation project. Small on purpose."],
            ["Company work", "A real brief: content, research, campus, design, or a test."],
            ["UPI", "Approved pay hits the wallet, then your bank or UPI."],
          ].map(([title, body], index) => (
            <li key={title} className="rounded-card border border-line bg-panel p-4">
              <p className="font-display text-sm font-extrabold text-lime">0{index + 1}</p>
              <h3 className="mt-3 font-display text-lg font-bold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-mute">{body}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-y border-line bg-panel/40" id="projects">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs font-bold tracking-[0.18em] text-lime uppercase">02 — Project studio</p>
              <h2 className="mt-3 font-display text-4xl font-extrabold tracking-tight sm:text-5xl">What the work actually is.</h2>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-mute">
                Twelve categories from the public teen page, written as briefs you can read before you download anything. Pin the ones that fit. They stay on this device.
              </p>
            </div>
            <div className="flex gap-2" role="group" aria-label="Sort projects">
              {(
                [
                  ["fit", "Best fit"],
                  ["pay", "Higher pay"],
                  ["quick", "Shorter"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setSort(id)}
                  className={
                    sort === id
                      ? "h-11 rounded-xl bg-lime px-3 text-sm font-bold text-ink"
                      : "h-11 rounded-xl border border-line px-3 text-sm font-bold text-cream"
                  }
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-6 flex gap-2 overflow-x-auto pb-2" role="tablist" aria-label="Categories">
            <button
              type="button"
              role="tab"
              aria-selected={filter === "all"}
              onClick={() => setFilter("all")}
              className={
                filter === "all"
                  ? "h-11 shrink-0 rounded-full bg-cream px-4 text-sm font-bold text-ink"
                  : "h-11 shrink-0 rounded-full border border-line px-4 text-sm font-semibold text-cream"
              }
            >
              All
            </button>
            {categories.map((category) => (
              <button
                key={category.id}
                type="button"
                role="tab"
                aria-selected={filter === category.id}
                onClick={() => setFilter(category.id)}
                className={
                  filter === category.id
                    ? "h-11 shrink-0 rounded-full bg-cream px-4 text-sm font-bold text-ink"
                    : "h-11 shrink-0 rounded-full border border-line px-4 text-sm font-semibold text-cream"
                }
              >
                {category.label}
              </button>
            ))}
          </div>

          <div className="mt-4 flex gap-3 overflow-x-auto pb-2">
            {visible.map((project) => (
              <button
                key={project.id}
                type="button"
                onClick={() => setActiveId(project.id)}
                className={
                  project.id === active?.id
                    ? "w-64 shrink-0 rounded-card border border-lime bg-panel p-4 text-left"
                    : "w-64 shrink-0 rounded-card border border-line bg-ink p-4 text-left"
                }
              >
                <span className="text-xs font-bold tracking-wide text-lime uppercase">{project.kind}</span>
                <span className="mt-2 block font-display text-lg leading-tight font-bold">{project.title}</span>
                <span className="mt-3 flex items-center justify-between text-sm">
                  <span className="text-mute">{project.where}</span>
                  <span className="font-extrabold text-cream">{project.payLabel}</span>
                </span>
              </button>
            ))}
          </div>

          {active ? (
            <article className="mt-4 grid gap-6 rounded-card border border-line bg-ink p-5 lg:grid-cols-[auto_1fr_auto] lg:p-7">
              <div className="grid size-12 place-items-center rounded-2xl bg-lime text-ink">
                <Icon className="size-6" />
              </div>
              <div>
                <p className="text-xs font-bold tracking-[0.16em] text-coral uppercase">
                  {categories.find((category) => category.id === active.category)?.label} · {active.client}
                </p>
                <h3 className="mt-2 font-display text-3xl font-extrabold tracking-tight">{active.title}</h3>
                <p className="mt-3 max-w-2xl text-sm leading-relaxed text-mute">{active.summary}</p>
                <dl className="mt-5 grid gap-4 sm:grid-cols-3">
                  <div>
                    <dt className="text-xs font-bold tracking-wide text-lime uppercase">You bring</dt>
                    <dd className="mt-1 text-sm leading-relaxed">{active.youBring}</dd>
                  </div>
                  <div>
                    <dt className="text-xs font-bold tracking-wide text-lime uppercase">Proof</dt>
                    <dd className="mt-1 text-sm leading-relaxed">{active.proof}</dd>
                  </div>
                  <div>
                    <dt className="text-xs font-bold tracking-wide text-lime uppercase">Skill</dt>
                    <dd className="mt-1 text-sm leading-relaxed">{active.skill}</dd>
                  </div>
                </dl>
              </div>
              <div className="flex flex-row items-end justify-between gap-4 lg:flex-col lg:items-stretch">
                <div>
                  <p className="font-display text-3xl font-extrabold">{active.payLabel}</p>
                  <p className="text-sm text-mute">
                    {active.minutes < 60 ? `${active.minutes} min` : `${Math.round(active.minutes / 60)} hrs`} · {active.where}
                  </p>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row lg:flex-col">
                  <button
                    type="button"
                    onClick={() => toggleSave(active)}
                    className="h-12 rounded-xl bg-lime px-4 text-sm font-bold text-ink"
                  >
                    {saved.includes(active.id) ? "Pinned" : "Pin to my board"}
                  </button>
                  <a
                    href={official.earn}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line px-4 text-sm font-bold"
                  >
                    Do this in the app
                    <ExternalLink className="size-4" />
                  </a>
                </div>
              </div>
            </article>
          ) : null}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16" id="money">
        <p className="text-xs font-bold tracking-[0.18em] text-lime uppercase">03 — Money, without the fog</p>
        <h2 className="mt-3 max-w-2xl font-display text-4xl font-extrabold tracking-tight sm:text-5xl">
          Age, a honest range, and what Groscore is for.
        </h2>
        <div className="mt-8 grid gap-4 lg:grid-cols-3">
          <article className="rounded-card border border-line bg-panel p-5">
            <h3 className="font-display text-2xl font-extrabold">Can you take company work?</h3>
            <label className="mt-4 block text-sm font-semibold" htmlFor="age">
              Age {age}
            </label>
            <input
              id="age"
              type="range"
              min={10}
              max={25}
              value={age}
              onChange={(event) => setAge(Number(event.target.value))}
            />
            <p className="font-display text-xl font-bold text-lime">{path.title}</p>
            <ul className="mt-3 grid gap-2 text-sm leading-relaxed text-mute">
              {path.points.map((point) => (
                <li key={point}>{point}</li>
              ))}
            </ul>
          </article>

          <article className="rounded-card bg-cream p-5 text-ink">
            <h3 className="font-display text-2xl font-extrabold">If the hours found work</h3>
            <label className="mt-4 block text-sm font-semibold" htmlFor="hours">
              {hours} hours a week
            </label>
            <input
              id="hours"
              type="range"
              min={2}
              max={16}
              value={hours}
              onChange={(event) => setHours(Number(event.target.value))}
            />
            <label className="mt-2 block text-sm font-semibold" htmlFor="calc-cat">
              Category
            </label>
            <select
              id="calc-cat"
              value={calcCat}
              onChange={(event) => setCalcCat(event.target.value as CategoryId)}
              className="mt-2 h-12 w-full rounded-xl border border-ink/15 bg-cream px-3 text-sm font-semibold"
            >
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.label}
                </option>
              ))}
            </select>
            <p className="mt-4 font-display text-3xl font-extrabold tracking-tight">
              {inr(low)}–{inr(high)}
            </p>
            <p className="mt-1 text-sm text-ink/70">Illustrative month. Not a promise, a quote, or a salary.</p>
            <p className="mt-3 text-sm leading-relaxed text-ink/80">{band.note}</p>
          </article>

          <article className="rounded-card border border-line bg-panel p-5">
            <h3 className="font-display text-2xl font-extrabold">Groscore, as a model</h3>
            <p className="mt-2 font-display text-5xl font-extrabold text-lime">{score}</p>
            <p className="text-sm text-mute">out of 1,000 in this teaching meter</p>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-ink">
              <div className="h-full rounded-full bg-lime" style={{ width: `${score / 10}%` }} />
            </div>
            <ul className="mt-4 grid gap-2">
              {(
                [
                  ["ontime", "Submit on time"],
                  ["profile", "Profile actually filled"],
                  ["clan", "Show up in a clan"],
                  ["repeat", "A brand approves you twice"],
                ] as const
              ).map(([key, label]) => (
                <li key={key}>
                  <label className="flex min-h-11 items-center gap-3 text-sm font-semibold">
                    <input
                      type="checkbox"
                      checked={habits[key]}
                      onChange={() => setHabits((current) => ({ ...current, [key]: !current[key] }))}
                      className="size-5 accent-lime"
                    />
                    {label}
                  </label>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-sm leading-relaxed text-mute">
              The real score lives in the app. A higher one is described as unlocking better company projects.
            </p>
          </article>
        </div>

        <ol className="mt-4 grid gap-3 md:grid-cols-5">
          {["Pick a brief", "Do the work", "Submit proof", "Wallet credit", "UPI or bank"].map((step, index) => (
            <li key={step} className="rounded-card border border-line px-4 py-3">
              <span className="text-xs font-bold text-coral">0{index + 1}</span>
              <p className="mt-1 font-semibold">{step}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-y border-line" id="growth">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 py-16 lg:grid-cols-[1fr_0.8fr]">
          <div>
            <p className="text-xs font-bold tracking-[0.18em] text-lime uppercase">04 — Ladder</p>
            <h2 className="mt-3 font-display text-4xl font-extrabold tracking-tight">Start small. Don’t pretend it’s a company yet.</h2>
            <div className="mt-6 grid gap-3">
              {ladder.map((step) => (
                <article key={step.stage} className="rounded-card border border-line bg-panel p-5">
                  <p className="text-xs font-bold tracking-wide text-lime uppercase">{step.stage}</p>
                  <h3 className="mt-2 font-display text-2xl font-extrabold">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-mute">{step.body}</p>
                  <p className="mt-3 text-sm font-bold text-cream">{step.range}</p>
                </article>
              ))}
            </div>
          </div>
          <article className="h-fit rounded-card bg-cream p-6 text-ink">
            <p className="text-xs font-bold tracking-[0.16em] uppercase text-ink/50">Experience note · preview</p>
            <label className="mt-4 block text-sm font-bold" htmlFor="cert-name">
              Name on the note
            </label>
            <input
              id="cert-name"
              value={name}
              maxLength={32}
              onChange={(event) => setName(event.target.value)}
              className="mt-2 h-12 w-full rounded-xl border border-ink/15 bg-cream-dim px-3 font-semibold"
            />
            <h3 className="mt-6 font-display text-3xl font-extrabold leading-tight">
              {name.trim() || "Your name"} finished a {active ? categories.find((c) => c.id === active.category)?.label.toLowerCase() : "starter"} brief.
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-ink/75">
              Official certificates are issued inside Funngro after approved work. This card is a preview of what that proof is for: a portfolio line, not a poster.
            </p>
            <p className="mt-6 text-xs font-bold tracking-wide uppercase text-coral">Not an official certificate</p>
          </article>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16">
        <h2 className="font-display text-4xl font-extrabold tracking-tight">Three ways to spend the same year</h2>
        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          {[
            ["Wait for college", "A degree with nothing shipped. Recruiters still ask what you made."],
            ["Random cash apps", "Vague tasks, a fee to withdraw, no brand name on the brief."],
            ["A teenlancer year", "Named work, a wallet, an age rule you can show a parent, and a score that tracks whether you finish."],
          ].map(([title, body], index) => (
            <article
              key={title}
              className={
                index === 2
                  ? "rounded-card border border-lime bg-panel p-5"
                  : "rounded-card border border-line p-5"
              }
            >
              <h3 className="font-display text-2xl font-extrabold">{title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-mute">{body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="border-y border-line bg-panel/40" id="stories">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <p className="text-xs font-bold tracking-[0.18em] text-lime uppercase">05 — Public journeys</p>
          <h2 className="mt-3 font-display text-4xl font-extrabold tracking-tight">Everyone starts with one approved task.</h2>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-mute">
            These are community stories already told around Funngro. Totals are reported, not audited here. Copy the habit, not the screenshot.
          </p>
          <div className="mt-8 grid gap-4 md:grid-cols-2">
            {stories.map((story, index) => (
              <article
                key={story.name}
                className={
                  index === 0
                    ? "rounded-card bg-cream p-6 text-ink md:col-span-2"
                    : "rounded-card border border-line bg-ink p-6"
                }
              >
                <div className="flex items-baseline justify-between gap-4">
                  <h3 className="font-display text-2xl font-extrabold">{story.name}</h3>
                  <p className="text-sm font-bold">{story.city}</p>
                </div>
                <p className="mt-3 max-w-3xl text-base leading-relaxed">{story.quote}</p>
                <p className="mt-4 font-display text-3xl font-extrabold text-coral">{story.figure}</p>
                <p className="text-xs font-semibold uppercase tracking-wide opacity-70">{story.note}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16">
        <p className="text-xs font-bold tracking-[0.18em] text-lime uppercase">06 — The part brochures skip</p>
        <h2 className="mt-3 max-w-2xl font-display text-4xl font-extrabold tracking-tight">
          A lot of the company is run by people who started as users.
        </h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Support", "First replies and brand onboarding, staffed by young Indians."],
            ["Quality", "Community QA and bug bashes before a release ships."],
            ["Content", "Social and in-app creative made by the audience itself."],
            ["Clans", "About a hundred clan leaders across large earner groups."],
          ].map(([title, body]) => (
            <article key={title} className="rounded-card border border-line p-5">
              <h3 className="font-display text-xl font-extrabold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-mute">{body}</p>
            </article>
          ))}
        </div>
        <ol className="mt-8 grid gap-4 md:grid-cols-4">
          {timeline.map((item) => (
            <li key={item.when} className="border-t border-lime pt-3">
              <p className="font-display text-lg font-extrabold text-lime">{item.when}</p>
              <p className="mt-2 text-sm leading-relaxed text-mute">{item.text}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-t border-line" id="faq">
        <div className="mx-auto max-w-3xl px-5 py-16">
          <h2 className="font-display text-4xl font-extrabold tracking-tight">Questions, answered in public language.</h2>
          <div className="mt-6 divide-y divide-line border-y border-line">
            {earnerFaq.map((item) => (
              <details key={item.q} className="group py-4">
                <summary className="flex min-h-11 cursor-pointer items-center justify-between gap-4 font-semibold">
                  {item.q}
                  <span className="text-lime group-open:hidden">+</span>
                  <span className="hidden text-lime group-open:inline">–</span>
                </summary>
                <p className="mt-3 text-sm leading-relaxed text-mute">{item.a}</p>
              </details>
            ))}
          </div>
          <p className="mt-6 text-sm text-mute">
            Hiring instead? <Link to="/companies" className="font-bold text-lime">Open the company side.</Link>
          </p>
        </div>
      </section>

      <section className="px-5 pb-24">
        <div className="mx-auto max-w-6xl rounded-card bg-lime px-6 py-12 text-ink sm:px-10">
          <h2 className="max-w-xl font-display text-4xl font-extrabold tracking-tight sm:text-5xl">
            Enrollment is on Funngro. This page gets you ready.
          </h2>
          <p className="mt-3 max-w-lg text-sm leading-relaxed">
            Free to join. OTP, projects, and UPI live in their app. Nothing here takes a payment or a password.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <a
              href={official.play}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex h-12 items-center justify-center rounded-xl bg-ink px-5 text-sm font-bold text-cream"
            >
              Get it on Google Play
            </a>
            <a
              href={official.ios}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex h-12 items-center justify-center rounded-xl border border-ink/20 px-5 text-sm font-bold"
            >
              App Store
            </a>
            <a
              href={official.earn}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex h-12 items-center justify-center rounded-xl border border-ink/20 px-5 text-sm font-bold"
            >
              Start on funngro.com
            </a>
          </div>
        </div>
      </section>

      <button
        type="button"
        onClick={() => setBoardOpen(true)}
        className="fixed bottom-5 left-4 z-40 h-12 rounded-full bg-cream px-4 text-sm font-bold text-ink shadow-lg"
      >
        My board · {saved.length}
      </button>

      {boardOpen ? (
        <div className="fixed inset-0 z-50 flex justify-end bg-ink/70" onClick={() => setBoardOpen(false)}>
          <aside
            role="dialog"
            aria-modal="true"
            aria-label="Pinned projects"
            className="h-full w-full max-w-md overflow-y-auto bg-cream p-6 text-ink"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-3xl font-extrabold">Your board</h2>
              <button type="button" className="h-11 px-3 text-sm font-bold" onClick={() => setBoardOpen(false)}>
                Close
              </button>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-ink/70">Saved only in this browser. Nothing is sent to a company.</p>
            {savedProjects.length === 0 ? (
              <p className="mt-8 text-sm">Pin a project from the studio and it will sit here.</p>
            ) : (
              <ul className="mt-6 grid gap-3">
                {savedProjects.map((project) => (
                  <li key={project.id} className="rounded-2xl bg-cream-dim p-4">
                    <p className="text-xs font-bold uppercase tracking-wide text-ink/50">{project.kind}</p>
                    <p className="mt-1 font-display text-xl font-extrabold">{project.title}</p>
                    <p className="mt-1 text-sm">{project.payLabel}</p>
                    <button
                      type="button"
                      className="mt-3 h-11 text-sm font-bold text-coral"
                      onClick={() => toggleSave(project)}
                    >
                      Remove
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </aside>
        </div>
      ) : null}

      {message ? (
        <p role="status" className="fixed right-4 bottom-24 z-50 max-w-xs rounded-2xl bg-cream px-4 py-3 text-sm font-bold text-ink shadow-lg">
          {message}
        </p>
      ) : null}
    </div>
  );
}
