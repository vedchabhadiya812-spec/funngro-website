import { Link } from "@tanstack/react-router";
import { ExternalLink } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Bar, BarChart, ResponsiveContainer, XAxis } from "recharts";
import { brandFaq, brandWorks, inr } from "@/data/content";
import { official } from "@/data/official";

const cities = ["Delhi", "Mumbai", "Bengaluru", "Hyderabad", "Pune", "Jaipur", "Surat", "Kolkata"];

const actionRate: Record<string, number> = {
  promotion: 40,
  sampling: 120,
  referral: 80,
  content: 450,
  survey: 25,
  influencer: 700,
  testing: 350,
  ideation: 250,
};

const proofOptions = [
  { id: "shot", label: "Screenshot of the live post" },
  { id: "link", label: "A public link that still opens" },
  { id: "photo", label: "A photo taken this week" },
  { id: "code", label: "A survey completion code" },
  { id: "steps", label: "Bug steps someone else can follow" },
];

const growth = [
  { name: "W1", value: 35 },
  { name: "W2", value: 48 },
  { name: "W3", value: 42 },
  { name: "W4", value: 63 },
  { name: "W5", value: 58 },
  { name: "W6", value: 77 },
  { name: "W7", value: 91 },
];

export function CompanyHome() {
  const [goal, setGoal] = useState(brandWorks[0]?.id ?? "promotion");
  const [picked, setPicked] = useState<string[]>(["Delhi", "Bengaluru"]);
  const [band, setBand] = useState<"14–17" | "18–25" | "14–25">("14–25");
  const [budget, setBudget] = useState(50000);
  const [proofs, setProofs] = useState<string[]>(["shot", "link"]);
  const [copied, setCopied] = useState(false);
  const [chartOn, setChartOn] = useState(false);

  useEffect(() => setChartOn(true), []);

  const work = brandWorks.find((item) => item.id === goal) ?? brandWorks[0];
  const rate = actionRate[goal] ?? 100;
  const actions = Math.max(1, Math.floor(budget / rate));
  const proofLine = proofOptions
    .filter((item) => proofs.includes(item.id))
    .map((item) => item.label)
    .join("; ");

  const brief = useMemo(() => {
    const where = picked.length ? picked.join(", ") : "pan-India, remote-first";
    return [
      `Goal: ${work?.name ?? "Brand promotion"}.`,
      `Cohort: young Indians aged ${band} in ${where}.`,
      `Budget frame: ${inr(budget)} for verified actions, not impressions.`,
      `Illustrative yield: about ${actions} actions at ${inr(rate)} each. Funngro prices the live campaign.`,
      `What good looks like: ${work?.line ?? ""}`,
      `Best when: ${work?.goodFor ?? ""}`,
      proofLine ? `Proof we will accept: ${proofLine}.` : "Proof we will accept: still to be defined.",
      "Pay after approval. Do not ask anyone under 14 to do company work.",
    ].join(" ");
  }, [work, band, picked, budget, actions, rate, proofLine]);

  const mailHref = `mailto:${official.brandsMail}?subject=${encodeURIComponent("Youth brief — intro from the studio")}&body=${encodeURIComponent(
    `${brief}\n\nThis is an introduction, not a live campaign. Please reply with how to enroll the brand.`,
  )}`;

  function toggleCity(city: string) {
    setPicked((current) => (current.includes(city) ? current.filter((item) => item !== city) : [...current, city]));
  }

  function toggleProof(id: string) {
    setProofs((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  }

  function chooseWork(id: string) {
    setGoal(id);
    document.getElementById("brief")?.scrollIntoView({ behavior: "smooth" });
  }

  async function copyBrief() {
    try {
      await navigator.clipboard.writeText(brief);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="pb-8">
      <section className="mx-auto grid max-w-6xl items-end gap-10 px-5 py-14 lg:grid-cols-[1.1fr_0.9fr] lg:py-20">
        <div>
          <p className="text-xs font-bold tracking-[0.18em] text-coral uppercase">For companies</p>
          <h1 className="mt-4 font-display text-5xl leading-[0.95] font-extrabold tracking-tight sm:text-6xl">
            Reach is cheap.
            <span className="mt-2 block text-lime">A finished action is not.</span>
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-mute">
            Funngro’s public offer is 70 lakh young Indians who opted in to do something: promote, sample, refer, answer, test, or make the work. Draft the brief here — their site never lets you — then send it to them.
          </p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <a
              href={official.brands}
              target="_blank"
              rel="noreferrer noopener"
              className="tap inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-lime px-5 text-sm font-bold text-ink"
            >
              Enroll the brand
              <ExternalLink className="size-4" />
            </a>
            <a href="#brief" className="inline-flex h-12 items-center justify-center rounded-xl border border-line px-5 text-sm font-bold">
              Draft a brief first
            </a>
          </div>
        </div>
        <aside className="rounded-card border border-line bg-panel p-5">
          <p className="text-xs font-bold tracking-[0.16em] text-mute uppercase">Illustrative month</p>
          <h2 className="mt-2 font-display text-2xl font-extrabold">Actions, not a vanity chart</h2>
          <div className="mt-4 h-36">
            {chartOn ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={growth}>
                  <XAxis dataKey="name" tick={{ fill: "var(--color-mute)", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Bar dataKey="value" fill="var(--color-lime)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : null}
          </div>
          <dl className="mt-2 grid grid-cols-3 gap-3 text-sm">
            <div>
              <dt className="text-mute">Projects</dt>
              <dd className="font-display text-2xl font-extrabold">24</dd>
            </div>
            <div>
              <dt className="text-mute">Matched</dt>
              <dd className="font-display text-2xl font-extrabold">186</dd>
            </div>
            <div>
              <dt className="text-mute">Done</dt>
              <dd className="font-display text-2xl font-extrabold">94%</dd>
            </div>
          </dl>
          <p className="mt-3 text-xs text-mute">Sample figures for the layout. Not a live brand account.</p>
        </aside>
      </section>

      <section className="border-y border-line" id="problem">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 py-16 lg:grid-cols-2">
          <div>
            <p className="text-xs font-bold tracking-[0.18em] text-lime uppercase">The gap</p>
            <h2 className="mt-3 font-display text-4xl font-extrabold tracking-tight">Meta sells impressions. You still need someone to try the thing.</h2>
          </div>
          <div className="grid gap-3 text-sm leading-relaxed text-mute">
            <p>Promote it in their own words. Sample it and say what they thought. Refer one friend who would actually install. Fill a survey without mashing buttons. Break a build and write the steps.</p>
            <p>
              Campaigns on Funngro are reviewed before they go live. Their trust page rules out adult content, gambling, and MLM. Safety mail is{" "}
              <a className="font-bold text-cream" href={`mailto:${official.safetyMail}`}>
                {official.safetyMail}
              </a>
              .
            </p>
          </div>
        </div>
      </section>

      <section id="work" className="mx-auto max-w-6xl px-5 py-16">
        <h2 className="font-display text-4xl font-extrabold tracking-tight">Eight ways a brief can look.</h2>
        <p className="mt-3 max-w-xl text-sm text-mute">Tap one. It loads the builder underneath — the public brand page only describes the categories.</p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {brandWorks.map((item, index) => {
            const on = item.id === goal;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => chooseWork(item.id)}
                className={
                  on
                    ? "tap rounded-card border border-lime bg-panel p-5 text-left"
                    : "tap rounded-card border border-line p-5 text-left hover:border-cream"
                }
              >
                <p className="text-xs font-bold text-lime">0{index + 1}</p>
                <h3 className="mt-2 font-display text-2xl font-extrabold">{item.name}</h3>
                <p className="mt-2 text-sm leading-relaxed text-mute">{item.line}</p>
                <p className="mt-3 text-sm font-semibold text-cream">{item.goodFor}</p>
              </button>
            );
          })}
        </div>
      </section>

      <section id="brief" className="border-y border-line bg-cream text-ink">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 py-16 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="text-xs font-bold tracking-[0.18em] uppercase text-ink/50">Brief builder</p>
            <h2 className="mt-3 font-display text-4xl font-extrabold tracking-tight">Write it here. Send it to Funngro.</h2>
            <p className="mt-3 text-sm leading-relaxed text-ink/70">
              Nothing is submitted from this page. Copy it, or open a mail to {official.brandsMail}, then finish enrollment on their brand page.
            </p>
            <label className="mt-6 block text-sm font-bold" htmlFor="goal">
              Work type
            </label>
            <select
              id="goal"
              value={goal}
              onChange={(event) => setGoal(event.target.value)}
              className="mt-2 h-12 w-full rounded-xl border border-ink/15 bg-cream px-3 text-sm font-semibold"
            >
              {brandWorks.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
            <p className="mt-5 text-sm font-bold">Age band</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {(["14–17", "18–25", "14–25"] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setBand(option)}
                  className={
                    band === option
                      ? "h-11 rounded-full bg-ink px-4 text-sm font-bold text-cream"
                      : "h-11 rounded-full border border-ink/15 px-4 text-sm font-bold"
                  }
                >
                  {option}
                </button>
              ))}
            </div>
            {band !== "18–25" ? (
              <p className="mt-2 text-sm text-ink/70">Under 18 needs a parent and age proof. Under 14 is not company work.</p>
            ) : null}
            <p className="mt-5 text-sm font-bold">Cities</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {cities.map((city) => (
                <button
                  key={city}
                  type="button"
                  onClick={() => toggleCity(city)}
                  aria-pressed={picked.includes(city)}
                  className={
                    picked.includes(city)
                      ? "h-11 rounded-full bg-lime px-4 text-sm font-bold text-ink"
                      : "h-11 rounded-full border border-ink/15 px-4 text-sm font-semibold"
                  }
                >
                  {city}
                </button>
              ))}
            </div>
            <label className="mt-5 block text-sm font-bold" htmlFor="budget">
              Budget frame {inr(budget)}
            </label>
            <input
              id="budget"
              type="range"
              min={15000}
              max={200000}
              step={5000}
              value={budget}
              onChange={(event) => setBudget(Number(event.target.value))}
            />
            <p className="text-sm font-semibold">
              About {actions.toLocaleString("en-IN")} verified actions at an illustrative {inr(rate)} each.
            </p>
            <p className="mt-5 text-sm font-bold">Proof you will accept</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {proofOptions.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  aria-pressed={proofs.includes(item.id)}
                  onClick={() => toggleProof(item.id)}
                  className={
                    proofs.includes(item.id)
                      ? "min-h-11 rounded-full bg-ink px-4 text-sm font-bold text-cream"
                      : "min-h-11 rounded-full border border-ink/15 px-4 text-sm font-semibold"
                  }
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          <article className="rounded-card bg-ink p-6 text-cream">
            <p className="text-xs font-bold tracking-[0.16em] text-lime uppercase">Sample brief</p>
            <p className="mt-4 text-lg leading-relaxed">{brief}</p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <button type="button" onClick={copyBrief} className="tap h-12 rounded-xl bg-lime px-5 text-sm font-bold text-ink">
                {copied ? "Copied" : "Copy brief"}
              </button>
              <a href={mailHref} className="inline-flex h-12 items-center justify-center rounded-xl border border-line px-5 text-sm font-bold">
                Email {official.brandsMail}
              </a>
              <a
                href={official.brands}
                target="_blank"
                rel="noreferrer noopener"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line px-5 text-sm font-bold"
              >
                Open brand page
                <ExternalLink className="size-4" />
              </a>
            </div>
          </article>
        </div>
      </section>

      <section id="process" className="mx-auto max-w-6xl px-5 py-16">
        <h2 className="font-display text-4xl font-extrabold tracking-tight">Five steps. No hiring pipeline.</h2>
        <ol className="mt-8 grid gap-4 md:grid-cols-5">
          {[
            ["Post", "Say the action, the city, the age, and what proof you will accept."],
            ["Match", "People who opted into that kind of work see it."],
            ["Pick", "Review samples and past approvals. Not follower counts."],
            ["Review", "Accept, send back once, or reject with a reason."],
            ["Pay", "Approved work is how the wallet on their side gets credited."],
          ].map(([title, body], index) => (
            <li key={title} className="rounded-card border border-line p-4">
              <p className="text-xs font-bold text-coral">0{index + 1}</p>
              <h3 className="mt-2 font-display text-xl font-extrabold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-mute">{body}</p>
            </li>
          ))}
        </ol>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <a
            href={official.brands}
            target="_blank"
            rel="noreferrer noopener"
            className="tap inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-lime px-5 text-sm font-bold text-ink"
          >
            Continue on Funngro
            <ExternalLink className="size-4" />
          </a>
          <Link to="/" className="inline-flex h-12 items-center justify-center rounded-xl border border-line px-5 text-sm font-bold">
            See the teen side
          </Link>
        </div>
      </section>

      <section id="faq" className="border-t border-line">
        <div className="mx-auto max-w-3xl px-5 py-16">
          <h2 className="font-display text-4xl font-extrabold tracking-tight">Before you brief a minor</h2>
          <div className="mt-6 divide-y divide-line border-y border-line">
            {brandFaq.map((item) => (
              <details key={item.q} className="group py-4">
                <summary className="flex min-h-11 cursor-pointer items-center justify-between gap-4 font-semibold">
                  {item.q}
                  <span className="text-lime group-open:hidden">+</span>
                  <span className="hidden text-lime group-open:inline">–</span>
                </summary>
                <p className="mt-3 text-sm leading-relaxed text-mute">{item.a}</p>
              </details>
            ))}
          </div>
          <p className="mt-8 text-sm text-mute">
            Official brand page:{" "}
            <a className="font-bold text-lime" href={official.brands} target="_blank" rel="noreferrer noopener">
              funngro.com/for-brands
            </a>
          </p>
        </div>
      </section>
    </div>
  );
}
