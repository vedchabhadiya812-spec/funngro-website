import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { ExternalLink, Menu, X } from "lucide-react";
import { useState } from "react";
import { official } from "@/data/official";

const teenLinks = [
  { label: "Match", hash: "launch" },
  { label: "How it works", hash: "how" },
  { label: "Projects", hash: "projects" },
  { label: "Money", hash: "money" },
  { label: "Stories", hash: "stories" },
  { label: "FAQ", hash: "faq" },
];

const brandLinks = [
  { label: "The gap", hash: "problem" },
  { label: "Work types", hash: "work" },
  { label: "Brief", hash: "brief" },
  { label: "Process", hash: "process" },
  { label: "FAQ", hash: "faq" },
];

export function SiteChrome({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const onBrand = path.startsWith("/companies");
  const links = onBrand ? brandLinks : teenLinks;
  const [open, setOpen] = useState(false);
  const year = new Date().getFullYear();

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:rounded-xl focus:bg-lime focus:px-3 focus:py-2 focus:text-ink"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-40 border-b border-line bg-ink/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-5">
          <Link to="/" className="flex items-center gap-2 font-display text-lg font-extrabold tracking-tight text-cream">
            <span className="grid size-9 place-items-center rounded-xl bg-lime text-base text-ink">F</span>
            funngro
          </Link>
          <nav className="ml-auto hidden items-center gap-5 lg:flex" aria-label="Primary">
            {links.map((link) => (
              <Link
                key={link.hash}
                to={onBrand ? "/companies" : "/"}
                hash={link.hash}
                className="text-sm font-semibold text-mute hover:text-cream"
              >
                {link.label}
              </Link>
            ))}
            <Link to={onBrand ? "/" : "/companies"} className="text-sm font-semibold text-cream">
              {onBrand ? "For teens" : "For companies"}
            </Link>
            <a
              href={onBrand ? official.brands : official.earn}
              target="_blank"
              rel="noreferrer noopener"
              className="tap inline-flex h-11 items-center gap-2 rounded-xl bg-lime px-4 text-sm font-bold text-ink"
            >
              {onBrand ? "Talk to Funngro" : "Enroll free"}
              <ExternalLink className="size-4" />
            </a>
          </nav>
          <button
            type="button"
            className="ml-auto grid size-11 place-items-center rounded-xl border border-line text-cream lg:hidden"
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
        {open ? (
          <nav className="border-t border-line px-5 py-3 lg:hidden" aria-label="Mobile">
            {links.map((link) => (
              <Link
                key={link.hash}
                to={onBrand ? "/companies" : "/"}
                hash={link.hash}
                className="block py-3 text-base font-semibold text-cream"
                onClick={() => setOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <Link
              to={onBrand ? "/" : "/companies"}
              className="block py-3 text-base font-semibold text-lime"
              onClick={() => setOpen(false)}
            >
              {onBrand ? "For teens" : "For companies"}
            </Link>
            <a
              href={onBrand ? official.brands : official.earn}
              target="_blank"
              rel="noreferrer noopener"
              className="mt-2 flex h-12 items-center justify-center gap-2 rounded-xl bg-lime text-base font-bold text-ink"
              onClick={() => setOpen(false)}
            >
              {onBrand ? "Talk to Funngro" : "Enroll free"}
              <ExternalLink className="size-4" />
            </a>
          </nav>
        ) : null}
      </header>
      <div id="main">{children}</div>
      <a
        href={onBrand ? official.brands : official.earn}
        target="_blank"
        rel="noreferrer noopener"
        className="tap fixed right-4 bottom-5 z-40 inline-flex h-12 items-center gap-2 rounded-full bg-lime px-4 text-sm font-bold text-ink shadow-lg lg:hidden"
      >
        {onBrand ? "Brief Funngro" : "Enroll free"}
        <ExternalLink className="size-4" />
      </a>
      <footer className="border-t border-line bg-ink">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:grid-cols-2 lg:grid-cols-4">
          <div className="sm:col-span-2 lg:col-span-1">
            <p className="font-display text-xl font-extrabold">funngro</p>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-mute">
              An interactive explainer of the teenlancer path. Figures come from Funngro’s public pages. This is not the official app and it does not take payments.
            </p>
          </div>
          <div className="grid gap-2 text-sm">
            <p className="font-bold text-cream">Here</p>
            <Link to="/" className="text-mute hover:text-cream">
              For teens
            </Link>
            <Link to="/companies" className="text-mute hover:text-cream">
              For companies
            </Link>
            <Link to="/" hash="projects" className="text-mute hover:text-cream">
              Sample projects
            </Link>
            <Link to="/" hash="money" className="text-mute hover:text-cream">
              Payout path
            </Link>
          </div>
          <div className="grid gap-2 text-sm">
            <p className="font-bold text-cream">Official</p>
            <a className="text-mute hover:text-cream" href={official.home} target="_blank" rel="noreferrer noopener">
              funngro.com
            </a>
            <a className="text-mute hover:text-cream" href={official.earn} target="_blank" rel="noreferrer noopener">
              Enroll — earn
            </a>
            <a className="text-mute hover:text-cream" href={official.play} target="_blank" rel="noreferrer noopener">
              Google Play
            </a>
            <a className="text-mute hover:text-cream" href={official.ios} target="_blank" rel="noreferrer noopener">
              App Store
            </a>
            <a className="text-mute hover:text-cream" href={official.brands} target="_blank" rel="noreferrer noopener">
              For brands
            </a>
            <a className="text-mute hover:text-cream" href={official.trust} target="_blank" rel="noreferrer noopener">
              Trust & safety
            </a>
          </div>
          <div className="grid gap-2 text-sm">
            <p className="font-bold text-cream">Social</p>
            <a className="text-mute hover:text-cream" href="https://www.instagram.com/funngro/" target="_blank" rel="noreferrer">
              Instagram
            </a>
            <a className="text-mute hover:text-cream" href="https://www.linkedin.com/company/funngro/" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
          </div>
        </div>
        <div className="mx-auto flex max-w-6xl flex-col gap-2 border-t border-line px-5 pt-5 pb-24 text-xs text-mute sm:flex-row sm:justify-between">
          <p>© {year} Funngro concept studio. Verify live numbers and rules in the official app.</p>
          <p>As seen on Shark Tank India, season 2. Backed by SucSEED.</p>
        </div>
      </footer>
    </>
  );
}
