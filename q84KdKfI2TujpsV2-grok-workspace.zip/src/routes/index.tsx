import { createFileRoute } from "@tanstack/react-router";
import { TeenHome } from "@/components/teen-home";

export const Route = createFileRoute("/")({
  component: TeenHome,
});
