import { createFileRoute } from "@tanstack/react-router";
import { CompanyHome } from "@/components/company-home";

export const Route = createFileRoute("/companies")({
  component: CompanyHome,
});
