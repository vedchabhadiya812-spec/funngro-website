/* =========================================================
   FUNNGRO / TEENLANCER — COMPLETE WEBSITE JAVASCRIPT
   Features:
   - Page entrance animation
   - Responsive mobile navigation
   - Smooth scrolling
   - Scroll reveal animations
   - Animated counters
   - Welcome text rotation
   - Subtle illustration parallax
   - Interactive card tilt
   - Opportunity filters and show more
   - Simulator tabs
   - FAQ accordion
   - Toast notifications
   - Back-to-top button
   - Reduced-motion accessibility
========================================================= */

document.addEventListener("DOMContentLoaded", () => {
    "use strict";

    const body = document.body;
    const navbar = document.getElementById("navbar");

    /* =====================================================
       1. PAGE LOADING / ENTRANCE ANIMATION
    ===================================================== */

    body.classList.add("page-loaded");

    window.addEventListener("load", () => {
        body.classList.add("page-ready");
    });

    /* =====================================================
       2. MOBILE NAVIGATION
    ===================================================== */

    const mobileMenuBtn = document.getElementById("mobileMenuBtn");
    const mobileMenu = document.getElementById("mobileMenu");

    function closeMobileMenu() {
        if (!mobileMenu || !mobileMenuBtn) return;

        mobileMenu.classList.remove("active", "open", "show");
        mobileMenuBtn.classList.remove("active", "open");
        mobileMenuBtn.setAttribute("aria-expanded", "false");
        body.classList.remove("menu-open");
    }

    function toggleMobileMenu() {
        if (!mobileMenu || !mobileMenuBtn) return;

        const isOpen = mobileMenu.classList.toggle("active");

        mobileMenu.classList.toggle("open", isOpen);
        mobileMenuBtn.classList.toggle("active", isOpen);
        mobileMenuBtn.classList.toggle("open", isOpen);
        mobileMenuBtn.setAttribute("aria-expanded", String(isOpen));
        body.classList.toggle("menu-open", isOpen);
    }

    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.setAttribute("aria-expanded", "false");

        mobileMenuBtn.addEventListener("click", (event) => {
            event.preventDefault();
            toggleMobileMenu();
        });

        mobileMenu.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", closeMobileMenu);
        });

        document.addEventListener("click", (event) => {
            const clickedInsideMenu = mobileMenu.contains(event.target);
            const clickedButton = mobileMenuBtn.contains(event.target);

            if (!clickedInsideMenu && !clickedButton) {
                closeMobileMenu();
            }
        });

        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape") {
                closeMobileMenu();
            }
        });

        window.addEventListener("resize", () => {
            if (window.innerWidth > 900) {
                closeMobileMenu();
            }
        });
    }

    /* =====================================================
       3. NAVBAR SCROLL EFFECT
    ===================================================== */

    function updateNavbar() {
        if (!navbar) return;

        if (window.scrollY > 40) {
            navbar.classList.add("scrolled");
        } else {
            navbar.classList.remove("scrolled");
        }
    }

    window.addEventListener("scroll", updateNavbar, { passive: true });
    updateNavbar();

    /* =====================================================
       4. SMOOTH SCROLLING FOR INTERNAL LINKS
    ===================================================== */

    document.querySelectorAll('a[href^="#"]').forEach((link) => {
        link.addEventListener("click", (event) => {
            const targetId = link.getAttribute("href");

            if (!targetId || targetId === "#") return;

            const target = document.querySelector(targetId);

            if (!target) return;

            event.preventDefault();
            closeMobileMenu();

            const navbarHeight = navbar
                ? navbar.getBoundingClientRect().height
                : 0;

            const targetPosition =
                target.getBoundingClientRect().top +
                window.scrollY -
                navbarHeight -
                12;

            window.scrollTo({
                top: Math.max(0, targetPosition),
                behavior: window.matchMedia(
                    "(prefers-reduced-motion: reduce)"
                ).matches
                    ? "auto"
                    : "smooth"
            });
        });
    });

    /* =====================================================
       5. SCROLL REVEAL ANIMATIONS
    ===================================================== */

    const revealSelectors = [
        ".reveal",
        ".reveal-up",
        ".reveal-left",
        ".reveal-right",
        ".fade-in",
        ".fade-up",
        ".animate-on-scroll",
        ".section-heading",
        ".feature-card",
        ".opportunity-card",
        ".testimonial-card",
        ".growth-card",
        ".step-card"
    ];

    const revealElements = document.querySelectorAll(
        revealSelectors.join(",")
    );

    const reducedMotion = window.matchMedia(
        "(prefers-reduced-motion: reduce)"
    ).matches;

    if ("IntersectionObserver" in window && !reducedMotion) {
        const revealObserver = new IntersectionObserver(
            (entries, observer) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("visible", "revealed");
                        observer.unobserve(entry.target);
                    }
                });
            },
            {
                threshold: 0.12,
                rootMargin: "0px 0px -40px 0px"
            }
        );

        revealElements.forEach((element) => {
            revealObserver.observe(element);
        });
    } else {
        revealElements.forEach((element) => {
            element.classList.add("visible", "revealed");
        });
    }

    /* =====================================================
       6. STAGGERED CARD ANIMATIONS
    ===================================================== */

    const cardGroups = [
        ".features-grid",
        ".opportunities-grid",
        ".growth-grid",
        ".steps-grid",
        ".testimonials-grid"
    ];

    cardGroups.forEach((selector) => {
        document.querySelectorAll(selector).forEach((group) => {
            const cards = group.children;

            Array.from(cards).forEach((card, index) => {
                card.style.setProperty(
                    "--animation-delay",
                    `${index * 100}ms`
                );

                card.classList.add("stagger-item");
            });
        });
    });

    /* =====================================================
       7. ANIMATED NUMBER COUNTERS
    ===================================================== */

    function animateCounter(element) {
        if (element.dataset.counted === "true") return;

        const targetValue =
            element.dataset.count ||
            element.dataset.target ||
            element.dataset.value;

        if (!targetValue) return;

        const target = Number(
            String(targetValue).replace(/,/g, "")
        );

        if (!Number.isFinite(target)) return;

        element.dataset.counted = "true";

        const duration = reducedMotion ? 0 : 1800;
        const startTime = performance.now();

        const originalText = element.textContent.trim();
        const prefix = originalText.match(/^[^\d-]*/)?.[0] || "";
        const suffix = originalText.match(/[^\d]*$/)?.[0] || "";

        function updateCounter(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = duration === 0
                ? 1
                : Math.min(elapsed / duration, 1);

            const easedProgress = 1 - Math.pow(1 - progress, 4);
            const currentValue = Math.round(target * easedProgress);

            element.textContent =
                prefix +
                currentValue.toLocaleString("en-IN") +
                suffix;

            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            } else {
                element.textContent =
                    prefix +
                    target.toLocaleString("en-IN") +
                    suffix;
            }
        }

        requestAnimationFrame(updateCounter);
    }

    const counterElements = document.querySelectorAll(
        "[data-count], [data-target], [data-value]"
    );

    if ("IntersectionObserver" in window) {
        const counterObserver = new IntersectionObserver(
            (entries, observer) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        animateCounter(entry.target);
                        observer.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.5 }
        );

        counterElements.forEach((counter) => {
            counterObserver.observe(counter);
        });
    } else {
        counterElements.forEach(animateCounter);
    }

    /* =====================================================
       8. WELCOME TEXT ROTATION
    ===================================================== */

    const welcomeChangingText = document.getElementById(
        "welcomeChangingText"
    );

    if (welcomeChangingText) {
        const welcomeWords = [
            "Dream Big.",
            "Learn More.",
            "Earn Early.",
            "Build Skills.",
            "Create Your Future."
        ];

        let welcomeIndex = 0;

        if (!reducedMotion) {
            setInterval(() => {
                welcomeChangingText.classList.add("text-changing");

                setTimeout(() => {
                    welcomeIndex =
                        (welcomeIndex + 1) % welcomeWords.length;

                    welcomeChangingText.textContent =
                        welcomeWords[welcomeIndex];

                    welcomeChangingText.classList.remove("text-changing");
                }, 250);
            }, 2600);
        }
    }

    /* =====================================================
       9. WELCOME ILLUSTRATION PARALLAX
    ===================================================== */

    const welcomeIllustration = document.querySelector(
        ".youth-welcome"
    );

    if (welcomeIllustration && !reducedMotion) {
        let ticking = false;

        window.addEventListener(
            "scroll",
            () => {
                if (ticking) return;

                ticking = true;

                requestAnimationFrame(() => {
                    const scrollAmount = Math.min(
                        window.scrollY * 0.08,
                        45
                    );

                    welcomeIllustration.style.transform =
                        `translate3d(0, ${scrollAmount}px, 0)`;

                    ticking = false;
                });
            },
            { passive: true }
        );
    }

    /* =====================================================
       10. INTERACTIVE CARD HOVER / TILT EFFECT
    ===================================================== */

    const tiltCards = document.querySelectorAll(
        ".feature-card, .opportunity-card, .growth-card"
    );

    if (!reducedMotion && window.matchMedia("(hover: hover)").matches) {
        tiltCards.forEach((card) => {
            card.addEventListener("mousemove", (event) => {
                const rect = card.getBoundingClientRect();

                const x = event.clientX - rect.left;
                const y = event.clientY - rect.top;

                const centerX = rect.width / 2;
                const centerY = rect.height / 2;

                const rotateX = ((y - centerY) / centerY) * -3;
                const rotateY = ((x - centerX) / centerX) * 3;

                card.style.transform =
                    `perspective(900px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-5px)`;
            });

            card.addEventListener("mouseleave", () => {
                card.style.transform = "";
            });
        });
    }

    /* =====================================================
       11. OPPORTUNITY FILTERS
       Works when filter buttons use data-filter
       and cards use data-category.
    ===================================================== */

    const filterButtons = document.querySelectorAll("[data-filter]");
    const opportunityCards = document.querySelectorAll(
        "[data-category]"
    );

    if (filterButtons.length && opportunityCards.length) {
        filterButtons.forEach((button) => {
            button.addEventListener("click", () => {
                const selectedFilter =
                    button.dataset.filter.toLowerCase();

                filterButtons.forEach((item) => {
                    item.classList.remove("active", "selected");
                    item.setAttribute("aria-pressed", "false");
                });

                button.classList.add("active", "selected");
                button.setAttribute("aria-pressed", "true");

                opportunityCards.forEach((card) => {
                    const categories = (
                        card.dataset.category || ""
                    )
                        .toLowerCase()
                        .split(/\s+/);

                    const shouldShow =
                        selectedFilter === "all" ||
                        categories.includes(selectedFilter);

                    card.hidden = !shouldShow;
                    card.classList.toggle("filtered-out", !shouldShow);
                });
            });
        });
    }

    /* =====================================================
       12. SHOW MORE / SHOW LESS
    ===================================================== */

    document.querySelectorAll("[data-show-more]").forEach((button) => {
        button.addEventListener("click", () => {
            const targetSelector = button.dataset.showMore;
            const target = targetSelector
                ? document.querySelector(targetSelector)
                : button.parentElement;

            if (!target) return;

            const isExpanded =
                button.getAttribute("aria-expanded") === "true";

            target.classList.toggle("expanded", !isExpanded);
            button.setAttribute(
                "aria-expanded",
                String(!isExpanded)
            );

            button.textContent = isExpanded
                ? "Show More"
                : "Show Less";
        });
    });

    /* =====================================================
       13. SIMULATOR TABS
    ===================================================== */

    const simulatorTabs = document.querySelectorAll(
        "[data-simulator-tab]"
    );

    const simulatorPanels = document.querySelectorAll(
        "[data-simulator-panel]"
    );

    if (simulatorTabs.length && simulatorPanels.length) {
        simulatorTabs.forEach((tab) => {
            tab.addEventListener("click", () => {
                const selectedTab =
                    tab.dataset.simulatorTab;

                simulatorTabs.forEach((item) => {
                    const isActive = item === tab;

                    item.classList.toggle("active", isActive);
                    item.setAttribute(
                        "aria-selected",
                        String(isActive)
                    );
                    item.setAttribute(
                        "tabindex",
                        isActive ? "0" : "-1"
                    );
                });

                simulatorPanels.forEach((panel) => {
                    const isActive =
                        panel.dataset.simulatorPanel === selectedTab;

                    panel.hidden = !isActive;
                    panel.classList.toggle("active", isActive);
                });
            });
        });
    }

    /* =====================================================
       14. FAQ ACCORDION
    ===================================================== */

    const faqItems = document.querySelectorAll(
        ".faq-item"
    );

    faqItems.forEach((item) => {
        item.addEventListener("toggle", () => {
            if (!item.open) return;

            faqItems.forEach((otherItem) => {
                if (otherItem !== item) {
                    otherItem.open = false;
                }
            });
        });
    });

    /* =====================================================
       15. TOAST NOTIFICATIONS
    ===================================================== */

    const toast = document.getElementById("toast");
    const toastMessage = document.getElementById("toastMessage");

    let toastTimeout;

    function showToast(message) {
        if (!toast || !toastMessage) return;

        toastMessage.textContent = message;
        toast.classList.add("show", "active");
        toast.setAttribute("aria-hidden", "false");

        clearTimeout(toastTimeout);

        toastTimeout = setTimeout(() => {
            toast.classList.remove("show", "active");
            toast.setAttribute("aria-hidden", "true");
        }, 3000);
    }

    document.querySelectorAll("[data-toast]").forEach((button) => {
        button.addEventListener("click", () => {
            showToast(
                button.dataset.toast || "Thank you for your interest!"
            );
        });
    });

    /* =====================================================
       16. BACK TO TOP BUTTON
    ===================================================== */

    let backToTop = document.getElementById("backToTop");

    if (!backToTop) {
        backToTop = document.createElement("button");
        backToTop.id = "backToTop";
        backToTop.type = "button";
        backToTop.className = "back-to-top";
        backToTop.setAttribute("aria-label", "Back to top");
        backToTop.innerHTML = "↑";
        body.appendChild(backToTop);
    }

    function updateBackToTop() {
        backToTop.classList.toggle(
            "visible",
            window.scrollY > 500
        );
    }

    window.addEventListener("scroll", updateBackToTop, {
        passive: true
    });

    backToTop.addEventListener("click", () => {
        window.scrollTo({
            top: 0,
            behavior: reducedMotion ? "auto" : "smooth"
        });
    });

    updateBackToTop();

    /* =====================================================
       17. ACTIVE NAVIGATION LINK ON SCROLL
    ===================================================== */

    const pageSections = document.querySelectorAll(
        "main section[id], section[id]"
    );

    const navLinks = document.querySelectorAll(
        'nav a[href^="#"], #mobileMenu a[href^="#"]'
    );

    if ("IntersectionObserver" in window && pageSections.length) {
        const sectionObserver = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (!entry.isIntersecting) return;

                    const sectionId = entry.target.id;

                    navLinks.forEach((link) => {
                        const isCurrent =
                            link.getAttribute("href") === `#${sectionId}`;

                        link.classList.toggle("active", isCurrent);

                        if (isCurrent) {
                            link.setAttribute("aria-current", "location");
                        } else {
                            link.removeAttribute("aria-current");
                        }
                    });
                });
            },
            {
                rootMargin: "-35% 0px -55% 0px",
                threshold: 0
            }
        );

        pageSections.forEach((section) => {
            sectionObserver.observe(section);
        });
    }

    /* =====================================================
       18. BUTTON RIPPLE EFFECT
    ===================================================== */

    if (!reducedMotion) {
        document.querySelectorAll(
            ".btn, .button, .cta-button"
        ).forEach((button) => {
            button.addEventListener("click", (event) => {
                const rect = button.getBoundingClientRect();

                const ripple = document.createElement("span");

                ripple.className = "button-ripple";

                ripple.style.left =
                    `${event.clientX - rect.left}px`;

                ripple.style.top =
                    `${event.clientY - rect.top}px`;

                button.appendChild(ripple);

                setTimeout(() => {
                    ripple.remove();
                }, 650);
            });
        });
    }

    /* =====================================================
       19. FORM VALIDATION AND FEEDBACK
    ===================================================== */

    document.querySelectorAll("form").forEach((form) => {
        form.addEventListener("submit", (event) => {
            if (!form.checkValidity()) {
                event.preventDefault();
                form.reportValidity();
                return;
            }

            /*
              This script does not send form data to a server.
              Add your backend or form-service integration
              if the form needs to submit information.
            */

            const successMessage =
                form.dataset.successMessage ||
                "Thank you! Your response has been received.";

            if (form.dataset.localFeedback === "true") {
                event.preventDefault();
                showToast(successMessage);
                form.reset();
            }
        });
    });

    /* =====================================================
       20. IMAGE LAZY LOADING
    ===================================================== */

    document.querySelectorAll("img").forEach((image) => {
        if (!image.hasAttribute("loading")) {
            image.setAttribute("loading", "lazy");
        }

        if (!image.hasAttribute("decoding")) {
            image.setAttribute("decoding", "async");
        }
    });

    /* =====================================================
       21. EXTERNAL LINKS
    ===================================================== */

    document.querySelectorAll('a[target="_blank"]').forEach((link) => {
        const relValues = new Set(
            (link.getAttribute("rel") || "").split(/\s+/).filter(Boolean)
        );

        relValues.add("noopener");
        relValues.add("noreferrer");

        link.setAttribute("rel", [...relValues].join(" "));
    });

    /* =====================================================
       22. CURRENT YEAR
    ===================================================== */

    document.querySelectorAll("[data-current-year]").forEach((element) => {
        element.textContent = new Date().getFullYear();
    });

    /* =====================================================
       23. ACCESSIBILITY: KEYBOARD INTERACTION
    ===================================================== */

    document.querySelectorAll("[data-clickable]").forEach((element) => {
        if (
            element.tagName !== "BUTTON" &&
            element.tagName !== "A"
        ) {
            element.setAttribute("tabindex", "0");
            element.setAttribute("role", "button");

            element.addEventListener("keydown", (event) => {
                if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    element.click();
                }
            });
        }
    });

    /* =====================================================
       24. CONSOLE MESSAGE
    ===================================================== */

    console.log(
        "%cFunngro | Teenlancer",
        "font-size:20px;font-weight:bold;color:#6c4cff;"
    );

    console.log(
        "%cYour future starts with what you create today.",
        "font-size:12px;color:#777;"
    );

});