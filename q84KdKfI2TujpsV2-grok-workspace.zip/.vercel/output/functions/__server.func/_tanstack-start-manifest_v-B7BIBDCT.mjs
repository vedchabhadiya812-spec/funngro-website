//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B7BIBDCT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/companies"],
		preloads: ["/assets/index-BA39-q6J.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BA39-q6J.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Q_0F-N8j.js", "/assets/content-bztfa1Gi.js"]
	},
	"/companies": {
		filePath: "/workspace/src/routes/companies.tsx",
		children: void 0,
		preloads: ["/assets/companies-CYStfoE0.js", "/assets/content-bztfa1Gi.js"]
	}
} });
//#endregion
export { tsrStartManifest };
