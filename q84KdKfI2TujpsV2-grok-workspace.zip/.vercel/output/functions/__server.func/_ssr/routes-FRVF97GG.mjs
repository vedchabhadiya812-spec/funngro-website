import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Share2, c as PenLine, d as Megaphone, f as GraduationCap, g as AppWindow, h as BadgePercent, i as Smartphone, l as Mic, m as Clapperboard, o as Search, p as ExternalLink, r as Table2, s as PenTool } from "../_libs/lucide-react.mjs";
import { n as official, r as wallBrands } from "./router-B7G51j_a.mjs";
import { a as earnerFaq, c as ladder, d as timeline, i as categories, l as projects, o as hourBands, s as inr, t as agePath, u as stories } from "./content-BDpXuANd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-FRVF97GG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useToast() {
	const [message, setMessage] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!message) return;
		const timer = window.setTimeout(() => setMessage(null), 2800);
		return () => window.clearTimeout(timer);
	}, [message]);
	return {
		message,
		show: setMessage
	};
}
var steps = [
	{
		key: "age",
		prompt: "How old are you?",
		options: [
			{
				id: "under14",
				label: "Under 14",
				hint: "Company work is closed"
			},
			{
				id: "teen",
				label: "14–17",
				hint: "Parent plus age proof"
			},
			{
				id: "adult",
				label: "18–25",
				hint: "Full earner path"
			}
		]
	},
	{
		key: "time",
		prompt: "How long can you give this week?",
		options: [
			{
				id: "quick",
				label: "Under 30 min",
				hint: "Surveys, tagging, short posts"
			},
			{
				id: "evening",
				label: "One evening",
				hint: "Stories, copy, a voice take"
			},
			{
				id: "weekend",
				label: "A weekend",
				hint: "A reel, a poster set, a page"
			}
		]
	},
	{
		key: "gear",
		prompt: "What can you actually use?",
		options: [
			{
				id: "phone",
				label: "Just my phone",
				hint: "Enough for a first task"
			},
			{
				id: "canva",
				label: "Phone and Canva",
				hint: "Stories and posters"
			},
			{
				id: "laptop",
				label: "A laptop",
				hint: "Sheets, pages, longer edits"
			},
			{
				id: "store",
				label: "I can visit a store",
				hint: "Shelf notes, sampling"
			}
		]
	},
	{
		key: "style",
		prompt: "Where do you want the work to happen?",
		options: [
			{
				id: "home",
				label: "Stay in",
				hint: "Remote only"
			},
			{
				id: "out",
				label: "I can go out",
				hint: "Campus or a shop"
			},
			{
				id: "talk",
				label: "I like talking",
				hint: "Voice, referrals, campus"
			}
		]
	},
	{
		key: "goal",
		prompt: "What do you want from the first month?",
		options: [
			{
				id: "rupee",
				label: "A first rupee",
				hint: "Short, easy to finish"
			},
			{
				id: "portfolio",
				label: "Something to show",
				hint: "A named piece of work"
			},
			{
				id: "learn",
				label: "A skill",
				hint: "Practice before the big brief"
			}
		]
	}
];
var proofChecks = [
	{
		id: "brief",
		label: "It follows the brief, not a vibe I preferred"
	},
	{
		id: "mine",
		label: "The photo, voice, or file is mine — not stock"
	},
	{
		id: "phone",
		label: "A stranger can read it on a phone"
	},
	{
		id: "time",
		label: "I can submit before the deadline"
	},
	{
		id: "lang",
		label: "The language matches what they asked"
	},
	{
		id: "inside",
		label: "I will not take payment outside the app"
	}
];
var week = [
	{
		id: "dl",
		title: "Download",
		body: "Official app. OTP. No fee screen."
	},
	{
		id: "profile",
		title: "Interests",
		body: "City, skills, one honest sample."
	},
	{
		id: "parent",
		title: "Parent",
		body: "Under 18: approval and age proof."
	},
	{
		id: "toffee",
		title: "Toffee",
		body: "One short task. Finish it cleanly."
	},
	{
		id: "proof",
		title: "Proof",
		body: "Upload what they asked, nothing extra."
	},
	{
		id: "apply",
		title: "Company",
		body: "Apply only where your sample matches."
	},
	{
		id: "upi",
		title: "UPI",
		body: "Withdraw after approval, not before."
	}
];
function categoriesFor(answers) {
	const cats = /* @__PURE__ */ new Set();
	if (answers.time === "quick") {
		cats.add("research");
		cats.add("promo");
		cats.add("data");
		cats.add("influencer");
	}
	if (answers.time === "evening") {
		cats.add("social");
		cats.add("writing");
		cats.add("voice");
		cats.add("influencer");
	}
	if (answers.time === "weekend") {
		cats.add("video");
		cats.add("design");
		cats.add("web");
		cats.add("app");
	}
	if (answers.gear === "phone") {
		cats.add("social");
		cats.add("voice");
		cats.add("research");
	}
	if (answers.gear === "canva") {
		cats.add("design");
		cats.add("social");
	}
	if (answers.gear === "laptop") {
		cats.add("web");
		cats.add("data");
		cats.add("writing");
		cats.add("video");
	}
	if (answers.gear === "store" || answers.style === "out") {
		cats.add("research");
		cats.add("campus");
		cats.add("promo");
	}
	if (answers.style === "talk") {
		cats.add("voice");
		cats.add("influencer");
		cats.add("campus");
	}
	if (answers.style === "home") cats.delete("campus");
	return cats;
}
function recommend(answers) {
	const cats = categoriesFor(answers);
	let list = projects.filter((project) => cats.has(project.category));
	if (answers.age === "under14") list = [];
	if (answers.gear !== "store" && answers.style !== "out") list = list.filter((project) => project.where === "Remote");
	if (answers.goal === "rupee") list = [...list].sort((a, b) => a.minutes - b.minutes || (a.payInr ?? 0) - (b.payInr ?? 0));
	else if (answers.goal === "portfolio") list = [...list].sort((a, b) => (b.payInr ?? 0) - (a.payInr ?? 0));
	else list = [...list].sort((a, b) => (a.kind === "Evaluation" ? -1 : 1) - (b.kind === "Evaluation" ? -1 : 1));
	if (list.length < 3 && answers.age !== "under14") {
		const extra = projects.filter((project) => !list.some((item) => item.id === project.id) && project.where === "Remote");
		list = [...list, ...extra];
	}
	return list.slice(0, 3);
}
var emptyAnswers = {};
function LaunchPad({ onPick }) {
	const { show } = useToast();
	const [step, setStep] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)(emptyAnswers);
	const [proof, setProof] = (0, import_react.useState)([
		"brief",
		"mine",
		"inside"
	]);
	const [done, setDone] = (0, import_react.useState)([]);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem("funngro-week");
			if (raw) {
				const parsed = JSON.parse(raw);
				if (Array.isArray(parsed)) setDone(parsed.filter((id) => week.some((day) => day.id === id)));
			}
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem("funngro-week", JSON.stringify(done));
	}, [done, hydrated]);
	const complete = steps.every((item) => answers[item.key]);
	const picks = (0, import_react.useMemo)(() => complete ? recommend(answers) : [], [answers, complete]);
	const current = steps[step];
	const proofScore = proof.length;
	const readiness = Math.round((complete ? 34 : Object.keys(answers).length / steps.length * 20) + proofScore / proofChecks.length * 33 + done.length / week.length * 33);
	function choose(id) {
		if (!current) return;
		const next = {
			...answers,
			[current.key]: id
		};
		setAnswers(next);
		if (step < steps.length - 1) setStep(step + 1);
	}
	function toggleProof(id) {
		setProof((currentIds) => currentIds.includes(id) ? currentIds.filter((item) => item !== id) : [...currentIds, id]);
	}
	function toggleDay(id) {
		setDone((currentIds) => currentIds.includes(id) ? currentIds.filter((item) => item !== id) : [...currentIds, id]);
	}
	const parentNote = [
		"I want to join Funngro, a free app (no joining fee) where young Indians do short paid tasks for real brands — surveys, posts, sampling, design — and withdraw to UPI after the work is approved.",
		"Their public rule: under 14, no company projects. From 14, a parent approves and age proof is required.",
		`Official site: ${official.home}`,
		`Android: ${official.play}`,
		`iPhone: ${official.ios}`,
		"This note was written in a guide. The account is created only on Funngro."
	].join("\n\n");
	async function copyNote() {
		try {
			await navigator.clipboard.writeText(parentNote);
			show("Parent note copied");
		} catch {
			show("Select the note and copy it");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-y border-line bg-panel/40",
		id: "launch",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold tracking-[0.18em] text-coral uppercase",
					children: "The part their site does not do"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-col justify-between gap-4 lg:flex-row lg:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "max-w-2xl font-display text-4xl leading-tight font-extrabold tracking-tight sm:text-5xl",
						children: "Match a first brief. Then enroll on the real Funngro."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm leading-relaxed text-mute",
						children: "Four tools the marketing site does not ship: a fit match, a proof check, a seven-day plan, and a note for a parent. Accounts still open only in their app."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-4 lg:grid-cols-[1.15fr_0.85fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card bg-cream p-5 text-ink sm:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold tracking-[0.16em] text-ink/50 uppercase",
									children: "Fit match"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-bold",
									children: complete ? "Matched" : `${step + 1} / ${steps.length}`
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-2 overflow-hidden rounded-full bg-ink/10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-ink transition-[width] duration-300",
									style: { width: `${complete ? 100 : step / steps.length * 100}%` }
								})
							}),
							complete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 font-display text-3xl font-extrabold tracking-tight",
									children: answers.age === "under14" ? "Learn now. Enroll for pay at 14." : "Start with one of these."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-ink/70",
									children: answers.age === "under14" ? "Funngro’s public FAQ keeps company projects closed under 14. Open the app with a parent so you know the rule, and use the time to practise a tool." : answers.age === "teen" ? "You can earn once a parent approves and age proof is in. These are sample briefs, not live jobs." : "Sample briefs in the shape of live work. The real list is inside the app after you enroll."
								}),
								picks.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-5 grid gap-3",
									children: picks.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => onPick(project.id),
										className: "tap flex w-full items-center justify-between gap-3 rounded-2xl bg-cream-dim px-4 py-3 text-left",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "block text-xs font-bold tracking-wide text-ink/50 uppercase",
											children: [
												project.kind,
												" · ",
												categories.find((item) => item.id === project.category)?.label
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block font-display text-lg font-extrabold",
											children: project.title
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "shrink-0 text-sm font-extrabold",
											children: project.payLabel
										})]
									}) }, project.id))
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 flex flex-col gap-3 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: answers.age === "under14" ? official.faq : official.earn,
										target: "_blank",
										rel: "noreferrer noopener",
										className: "tap inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-ink px-4 text-sm font-bold text-cream",
										children: [answers.age === "under14" ? "Read the official age rule" : "Enroll on Funngro", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-12 rounded-xl border border-ink/15 px-4 text-sm font-bold",
										onClick: () => {
											setAnswers({});
											setStep(0);
										},
										children: "Match again"
									})]
								})
							] }) : current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 font-display text-3xl font-extrabold tracking-tight",
									children: current.prompt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-5 grid gap-3 sm:grid-cols-2",
									role: "group",
									"aria-label": current.prompt,
									children: current.options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => choose(option.id),
										className: "tap min-h-16 rounded-2xl border border-ink/10 bg-cream-dim px-4 py-3 text-left hover:border-ink",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-display text-lg font-extrabold",
											children: option.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-sm text-ink/60",
											children: option.hint
										})]
									}, option.id))
								}),
								step > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mt-4 h-11 text-sm font-bold",
									onClick: () => setStep((value) => value - 1),
									children: "Back"
								}) : null
							] }) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-card border border-line bg-ink p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-end justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold tracking-[0.16em] text-lime uppercase",
										children: "Ready to enroll"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 font-display text-5xl font-extrabold text-lime",
										children: readiness
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-40 text-right text-xs leading-relaxed text-mute",
										children: "Match, proof, and the week plan. Not a Groscore."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 h-2 overflow-hidden rounded-full bg-panel",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-full bg-lime",
										style: { width: `${readiness}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex flex-col gap-2 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: official.play,
										target: "_blank",
										rel: "noreferrer noopener",
										className: "tap inline-flex h-11 flex-1 items-center justify-center rounded-xl bg-lime text-sm font-bold text-ink",
										children: "Google Play"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: official.ios,
										target: "_blank",
										rel: "noreferrer noopener",
										className: "tap inline-flex h-11 flex-1 items-center justify-center rounded-xl border border-line text-sm font-bold",
										children: "App Store"
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-card border border-line p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl font-extrabold",
									children: "Proof lab"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-mute",
									children: "Tick what your submission will actually include. Their site says “upload proof”. It never lets you rehearse."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 grid gap-1",
									children: proofChecks.map((item) => {
										const on = proof.includes(item.id);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											"aria-pressed": on,
											onClick: () => toggleProof(item.id),
											className: "flex min-h-11 w-full items-center gap-3 text-left text-sm font-semibold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: on ? "grid size-5 shrink-0 place-items-center rounded-md bg-lime text-xs font-extrabold text-ink" : "size-5 shrink-0 rounded-md border border-line" }), item.label]
										}) }, item.id);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm font-bold text-cream",
									children: proofScore === proofChecks.length ? "This is what an approval looks like. Submit it in the app." : proofScore >= 4 ? "Close. Fix the gaps before you upload." : "This is how a first task gets rejected."
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-4 lg:grid-cols-[1.2fr_0.8fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card border border-line p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl font-extrabold",
							children: "Seven days. Saved on this phone."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-4 grid gap-2 sm:grid-cols-2",
							children: week.map((day, index) => {
								const on = done.includes(day.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-pressed": on,
									onClick: () => toggleDay(day.id),
									className: on ? "tap flex min-h-20 w-full gap-3 rounded-2xl bg-lime px-3 py-3 text-left text-ink" : "tap flex min-h-20 w-full gap-3 rounded-2xl border border-line px-3 py-3 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-display text-lg font-extrabold",
										children: ["0", index + 1]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-bold",
										children: day.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: on ? "mt-1 block text-sm text-ink/70" : "mt-1 block text-sm text-mute",
										children: day.body
									})] })]
								}) }, day.id);
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card bg-cream p-5 text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-2xl font-extrabold",
								children: "A note you can send a parent"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-ink/70",
								children: "Funngro publishes the rules. This turns them into one message, so you are not asking for a download with no context."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								readOnly: true,
								value: parentNote,
								className: "mt-4 h-40 w-full resize-none rounded-2xl border border-ink/10 bg-cream-dim p-3 text-sm leading-relaxed",
								"aria-label": "Note for a parent"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-col gap-2 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: copyNote,
									className: "tap h-12 rounded-xl bg-ink px-4 text-sm font-bold text-cream",
									children: "Copy note"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: official.trust,
									target: "_blank",
									rel: "noreferrer noopener",
									className: "inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-ink/15 px-4 text-sm font-bold",
									children: ["Safety page", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
								})]
							})
						]
					})]
				})
			]
		})
	});
}
function usePrefersReducedMotion() {
	const [reduced, setReduced] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const media = window.matchMedia("(prefers-reduced-motion: reduce)");
		const sync = () => setReduced(media.matches);
		sync();
		media.addEventListener("change", sync);
		return () => media.removeEventListener("change", sync);
	}, []);
	return reduced;
}
var icons = {
	social: Share2,
	video: Clapperboard,
	web: AppWindow,
	influencer: Megaphone,
	app: Smartphone,
	campus: GraduationCap,
	research: Search,
	data: Table2,
	voice: Mic,
	writing: PenLine,
	design: PenTool,
	promo: BadgePercent
};
var lines = [
	"Discover a project that fits this week",
	"Build proof, not just a poster",
	"Withdraw approved earnings to UPI",
	"Start with a short Toffee task"
];
var barHeights = [
	"h-3",
	"h-5",
	"h-4",
	"h-8",
	"h-6",
	"h-10",
	"h-8",
	"h-12"
];
function CountUp({ to, suffix }) {
	const reduced = usePrefersReducedMotion();
	const [value, setValue] = (0, import_react.useState)(reduced ? to : 0);
	const [node, setNode] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!node) return;
		if (reduced) {
			setValue(to);
			return;
		}
		const observer = new IntersectionObserver(([entry]) => {
			if (!entry?.isIntersecting) return;
			observer.disconnect();
			const start = performance.now();
			const tick = (now) => {
				const progress = Math.min(1, (now - start) / 1100);
				const eased = 1 - (1 - progress) ** 3;
				setValue(Math.round(to * eased));
				if (progress < 1) requestAnimationFrame(tick);
			};
			requestAnimationFrame(tick);
		}, { threshold: .6 });
		observer.observe(node);
		return () => observer.disconnect();
	}, [
		node,
		reduced,
		to
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		ref: setNode,
		children: [value.toLocaleString("en-IN"), suffix]
	});
}
function WalletBars() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4 flex h-12 items-end gap-1.5",
		"aria-hidden": "true",
		children: barHeights.map((height, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `flex-1 rounded-sm bg-ink/80 ${height}` }, index))
	});
}
function TeenHome() {
	const reduced = usePrefersReducedMotion();
	const { message, show } = useToast();
	const [line, setLine] = (0, import_react.useState)(0);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("fit");
	const [activeId, setActiveId] = (0, import_react.useState)(projects[0]?.id ?? "");
	const [saved, setSaved] = (0, import_react.useState)([]);
	const [name, setName] = (0, import_react.useState)("Aanya");
	const [age, setAge] = (0, import_react.useState)(16);
	const [hours, setHours] = (0, import_react.useState)(6);
	const [calcCat, setCalcCat] = (0, import_react.useState)("social");
	const [habits, setHabits] = (0, import_react.useState)({
		ontime: true,
		profile: true,
		clan: false,
		repeat: false
	});
	const [boardOpen, setBoardOpen] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem("funngro-studio");
			if (raw) {
				const parsed = JSON.parse(raw);
				if (typeof parsed.name === "string" && parsed.name.trim()) setName(parsed.name.slice(0, 32));
				if (Array.isArray(parsed.saved)) setSaved(parsed.saved.filter((id) => projects.some((project) => project.id === id)));
				if (typeof parsed.age === "number" && parsed.age >= 10 && parsed.age <= 25) setAge(parsed.age);
			}
		} catch {}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem("funngro-studio", JSON.stringify({
			name,
			saved,
			age
		}));
	}, [
		hydrated,
		name,
		saved,
		age
	]);
	(0, import_react.useEffect)(() => {
		if (reduced) return;
		const timer = window.setInterval(() => setLine((index) => (index + 1) % lines.length), 2800);
		return () => window.clearInterval(timer);
	}, [reduced]);
	(0, import_react.useEffect)(() => {
		if (!boardOpen) return;
		const onKey = (event) => {
			if (event.key === "Escape") setBoardOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [boardOpen]);
	const visible = (0, import_react.useMemo)(() => {
		const copy = [...projects.filter((project) => filter === "all" || project.category === filter)];
		if (sort === "pay") copy.sort((a, b) => (b.payInr ?? -1) - (a.payInr ?? -1));
		else if (sort === "quick") copy.sort((a, b) => a.minutes - b.minutes);
		return copy;
	}, [filter, sort]);
	(0, import_react.useEffect)(() => {
		if (!visible.some((project) => project.id === activeId) && visible[0]) setActiveId(visible[0].id);
	}, [visible, activeId]);
	const active = visible.find((project) => project.id === activeId) ?? visible[0] ?? projects[0];
	const path = agePath(age);
	const band = hourBands[calcCat];
	const low = hours * 4 * band.low;
	const high = hours * 4 * band.high;
	const score = 420 + (habits.ontime ? 140 : 0) + (habits.profile ? 90 : 0) + (habits.clan ? 80 : 0) + (habits.repeat ? 120 : 0);
	const savedProjects = projects.filter((project) => saved.includes(project.id));
	const Icon = active ? icons[active.category] : Share2;
	function toggleSave(project) {
		setSaved((current) => {
			return current.includes(project.id) ? current.filter((id) => id !== project.id) : [...current, project.id];
		});
		show(saved.includes(project.id) ? "Removed from your board" : `Pinned “${project.title}”`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "overflow-x-clip",
			id: "top",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-center gap-12 px-5 py-12 lg:grid-cols-[1.1fr_0.9fr] lg:py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "reveal text-xs font-bold tracking-[0.18em] text-coral uppercase",
						children: "Shark Tank India · Season 2 · SucSEED"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "reveal d1 mt-4 font-display text-5xl leading-[0.95] font-extrabold tracking-tight text-cream sm:text-6xl lg:text-7xl",
						children: ["Earn before 18.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 block text-lime",
							children: "With a brief, not a vibe."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "reveal d2 mt-5 max-w-xl text-base leading-relaxed text-mute sm:text-lg",
						children: "Funngro is the teenlancer path: young Indians take paid work from real brands — reels, surveys, sampling, design — then withdraw approved money to UPI. No joining fee."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "reveal d2 mt-3 text-sm font-semibold text-cream",
						"aria-live": "polite",
						children: lines[line]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "reveal d3 mt-7 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: official.earn,
							target: "_blank",
							rel: "noreferrer noopener",
							className: "tap inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-lime px-5 text-sm font-bold text-ink",
							children: ["Enroll on Funngro", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#launch",
							className: "inline-flex h-12 items-center justify-center rounded-xl border border-line px-5 text-sm font-bold text-cream",
							children: "Match me first"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "reveal d4 mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4",
						children: [
							[
								"70",
								"L+",
								"Young Indians"
							],
							[
								"5,000",
								"+",
								"Brands"
							],
							[
								"1,000",
								"+",
								"Live projects"
							],
							[
								"12",
								"+",
								"Categories"
							]
						].map(([num, suffix, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-display text-2xl font-extrabold text-cream",
							children: num === "70" || num === "12" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountUp, {
								to: Number(num),
								suffix: suffix ?? ""
							}) : num === "5,000" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountUp, {
								to: 5e3,
								suffix: "+"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountUp, {
								to: 1e3,
								suffix: "+"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-xs text-mute",
							children: label
						})] }, label))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative mx-auto w-full max-w-md",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "pass-notch relative rounded-card bg-cream p-6 text-ink shadow-[0_24px_60px_rgba(0,0,0,0.35)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold tracking-[0.16em] text-ink/60 uppercase",
										children: "Gro Money · sample"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-4xl font-extrabold tracking-tight",
										children: inr(4280)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-ink/70",
										children: "Illustrative month · not your balance"
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-coral px-3 py-1 text-xs font-bold text-cream",
									children: "Live brief"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletBars, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 border-t border-dashed border-ink/15 pt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-bold tracking-[0.14em] text-ink/50 uppercase",
									children: ["Matched for ", name || "you"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 grid gap-2",
									children: (savedProjects.length ? savedProjects : projects).slice(0, 3).map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-3 rounded-xl bg-cream-dim px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm font-bold",
											children: project.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-ink/60",
											children: project.where
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-extrabold",
											children: project.payLabel
										})]
									}, project.id))
								})]
							})
						]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-y border-line overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: official.home,
				target: "_blank",
				rel: "noreferrer noopener",
				className: "block py-4",
				"aria-label": "Open Funngro’s live brand wall",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "marquee gap-8 px-4 text-sm font-bold tracking-wide text-mute uppercase",
					children: [...wallBrands, ...wallBrands].map((brand, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-8",
						children: [brand, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-lime",
							children: "/"
						})]
					}, `${brand}-${index}`))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-5 pb-4 text-center text-xs text-mute",
				children: "Names on Funngro’s public wall. The live list is on their site — this row opens it."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LaunchPad, { onPick: (id) => {
			setFilter("all");
			setSort("fit");
			setActiveId(id);
			document.getElementById("projects")?.scrollIntoView({ behavior: reduced ? "auto" : "smooth" });
		} }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			id: "how",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold tracking-[0.18em] text-lime uppercase",
					children: "01 — The path"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 max-w-xl font-display text-4xl leading-tight font-extrabold tracking-tight sm:text-5xl",
					children: "From signup to a withdrawal you can explain."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 grid gap-4 md:grid-cols-5",
					children: [
						["Profile", "Interests, city, and a sample of what you can already do."],
						["Age check", "Under 14 stays with parents. 14+ needs a parent and age proof."],
						["First proof", "A Toffee task or an evaluation project. Small on purpose."],
						["Company work", "A real brief: content, research, campus, design, or a test."],
						["UPI", "Approved pay hits the wallet, then your bank or UPI."]
					].map(([title, body], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-card border border-line bg-panel p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-sm font-extrabold text-lime",
								children: ["0", index + 1]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-display text-lg font-bold",
								children: title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-mute",
								children: body
							})
						]
					}, title))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line bg-panel/40",
			id: "projects",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-between gap-4 sm:flex-row sm:items-end",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold tracking-[0.18em] text-lime uppercase",
								children: "02 — Project studio"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-4xl font-extrabold tracking-tight sm:text-5xl",
								children: "What the work actually is."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-xl text-sm leading-relaxed text-mute",
								children: "Twelve categories from the public teen page, written as briefs you can read before you download anything. Pin the ones that fit. They stay on this device."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2",
							role: "group",
							"aria-label": "Sort projects",
							children: [
								["fit", "Best fit"],
								["pay", "Higher pay"],
								["quick", "Shorter"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setSort(id),
								className: sort === id ? "h-11 rounded-xl bg-lime px-3 text-sm font-bold text-ink" : "h-11 rounded-xl border border-line px-3 text-sm font-bold text-cream",
								children: label
							}, id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex gap-2 overflow-x-auto pb-2",
						role: "tablist",
						"aria-label": "Categories",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": filter === "all",
							onClick: () => setFilter("all"),
							className: filter === "all" ? "h-11 shrink-0 rounded-full bg-cream px-4 text-sm font-bold text-ink" : "h-11 shrink-0 rounded-full border border-line px-4 text-sm font-semibold text-cream",
							children: "All"
						}), categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": filter === category.id,
							onClick: () => setFilter(category.id),
							className: filter === category.id ? "h-11 shrink-0 rounded-full bg-cream px-4 text-sm font-bold text-ink" : "h-11 shrink-0 rounded-full border border-line px-4 text-sm font-semibold text-cream",
							children: category.label
						}, category.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex gap-3 overflow-x-auto pb-2",
						children: visible.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setActiveId(project.id),
							className: project.id === active?.id ? "w-64 shrink-0 rounded-card border border-lime bg-panel p-4 text-left" : "w-64 shrink-0 rounded-card border border-line bg-ink p-4 text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold tracking-wide text-lime uppercase",
									children: project.kind
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block font-display text-lg leading-tight font-bold",
									children: project.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-3 flex items-center justify-between text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mute",
										children: project.where
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-extrabold text-cream",
										children: project.payLabel
									})]
								})
							]
						}, project.id))
					}),
					active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "mt-4 grid gap-6 rounded-card border border-line bg-ink p-5 lg:grid-cols-[auto_1fr_auto] lg:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-12 place-items-center rounded-2xl bg-lime text-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-bold tracking-[0.16em] text-coral uppercase",
									children: [
										categories.find((category) => category.id === active.category)?.label,
										" · ",
										active.client
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 font-display text-3xl font-extrabold tracking-tight",
									children: active.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-2xl text-sm leading-relaxed text-mute",
									children: active.summary
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-5 grid gap-4 sm:grid-cols-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-xs font-bold tracking-wide text-lime uppercase",
											children: "You bring"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 text-sm leading-relaxed",
											children: active.youBring
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-xs font-bold tracking-wide text-lime uppercase",
											children: "Proof"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 text-sm leading-relaxed",
											children: active.proof
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-xs font-bold tracking-wide text-lime uppercase",
											children: "Skill"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 text-sm leading-relaxed",
											children: active.skill
										})] })
									]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-row items-end justify-between gap-4 lg:flex-col lg:items-stretch",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl font-extrabold",
									children: active.payLabel
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-mute",
									children: [
										active.minutes < 60 ? `${active.minutes} min` : `${Math.round(active.minutes / 60)} hrs`,
										" · ",
										active.where
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2 sm:flex-row lg:flex-col",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => toggleSave(active),
										className: "h-12 rounded-xl bg-lime px-4 text-sm font-bold text-ink",
										children: saved.includes(active.id) ? "Pinned" : "Pin to my board"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: official.earn,
										target: "_blank",
										rel: "noreferrer noopener",
										className: "inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line px-4 text-sm font-bold",
										children: ["Do this in the app", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
									})]
								})]
							})
						]
					}) : null
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			id: "money",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold tracking-[0.18em] text-lime uppercase",
					children: "03 — Money, without the fog"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 max-w-2xl font-display text-4xl font-extrabold tracking-tight sm:text-5xl",
					children: "Age, a honest range, and what Groscore is for."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-4 lg:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-card border border-line bg-panel p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl font-extrabold",
									children: "Can you take company work?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-4 block text-sm font-semibold",
									htmlFor: "age",
									children: ["Age ", age]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "age",
									type: "range",
									min: 10,
									max: 25,
									value: age,
									onChange: (event) => setAge(Number(event.target.value))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-xl font-bold text-lime",
									children: path.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 grid gap-2 text-sm leading-relaxed text-mute",
									children: path.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: point }, point))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-card bg-cream p-5 text-ink",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl font-extrabold",
									children: "If the hours found work"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-4 block text-sm font-semibold",
									htmlFor: "hours",
									children: [hours, " hours a week"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "hours",
									type: "range",
									min: 2,
									max: 16,
									value: hours,
									onChange: (event) => setHours(Number(event.target.value))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mt-2 block text-sm font-semibold",
									htmlFor: "calc-cat",
									children: "Category"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									id: "calc-cat",
									value: calcCat,
									onChange: (event) => setCalcCat(event.target.value),
									className: "mt-2 h-12 w-full rounded-xl border border-ink/15 bg-cream px-3 text-sm font-semibold",
									children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: category.id,
										children: category.label
									}, category.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 font-display text-3xl font-extrabold tracking-tight",
									children: [
										inr(low),
										"–",
										inr(high)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-ink/70",
									children: "Illustrative month. Not a promise, a quote, or a salary."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-ink/80",
									children: band.note
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-card border border-line bg-panel p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-2xl font-extrabold",
									children: "Groscore, as a model"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 font-display text-5xl font-extrabold text-lime",
									children: score
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-mute",
									children: "out of 1,000 in this teaching meter"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 h-2 overflow-hidden rounded-full bg-ink",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-full bg-lime",
										style: { width: `${score / 10}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 grid gap-2",
									children: [
										["ontime", "Submit on time"],
										["profile", "Profile actually filled"],
										["clan", "Show up in a clan"],
										["repeat", "A brand approves you twice"]
									].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex min-h-11 items-center gap-3 text-sm font-semibold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: habits[key],
											onChange: () => setHabits((current) => ({
												...current,
												[key]: !current[key]
											})),
											className: "size-5 accent-lime"
										}), label]
									}) }, key))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-mute",
									children: "The real score lives in the app. A higher one is described as unlocking better company projects."
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 grid gap-3 md:grid-cols-5",
					children: [
						"Pick a brief",
						"Do the work",
						"Submit proof",
						"Wallet credit",
						"UPI or bank"
					].map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-card border border-line px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-bold text-coral",
							children: ["0", index + 1]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-semibold",
							children: step
						})]
					}, step))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line",
			id: "growth",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-8 px-5 py-16 lg:grid-cols-[1fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-[0.18em] text-lime uppercase",
						children: "04 — Ladder"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl font-extrabold tracking-tight",
						children: "Start small. Don’t pretend it’s a company yet."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 grid gap-3",
						children: ladder.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "rounded-card border border-line bg-panel p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold tracking-wide text-lime uppercase",
									children: step.stage
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 font-display text-2xl font-extrabold",
									children: step.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-mute",
									children: step.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm font-bold text-cream",
									children: step.range
								})
							]
						}, step.stage))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "h-fit rounded-card bg-cream p-6 text-ink",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold tracking-[0.16em] uppercase text-ink/50",
							children: "Experience note · preview"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm font-bold",
							htmlFor: "cert-name",
							children: "Name on the note"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "cert-name",
							value: name,
							maxLength: 32,
							onChange: (event) => setName(event.target.value),
							className: "mt-2 h-12 w-full rounded-xl border border-ink/15 bg-cream-dim px-3 font-semibold"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "mt-6 font-display text-3xl font-extrabold leading-tight",
							children: [
								name.trim() || "Your name",
								" finished a ",
								active ? categories.find((c) => c.id === active.category)?.label.toLowerCase() : "starter",
								" brief."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-ink/75",
							children: "Official certificates are issued inside Funngro after approved work. This card is a preview of what that proof is for: a portfolio line, not a poster."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-xs font-bold tracking-wide uppercase text-coral",
							children: "Not an official certificate"
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl font-extrabold tracking-tight",
				children: "Three ways to spend the same year"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 lg:grid-cols-3",
				children: [
					["Wait for college", "A degree with nothing shipped. Recruiters still ask what you made."],
					["Random cash apps", "Vague tasks, a fee to withdraw, no brand name on the brief."],
					["A teenlancer year", "Named work, a wallet, an age rule you can show a parent, and a score that tracks whether you finish."]
				].map(([title, body], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: index === 2 ? "rounded-card border border-lime bg-panel p-5" : "rounded-card border border-line p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl font-extrabold",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-mute",
						children: body
					})]
				}, title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line bg-panel/40",
			id: "stories",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-[0.18em] text-lime uppercase",
						children: "05 — Public journeys"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl font-extrabold tracking-tight",
						children: "Everyone starts with one approved task."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-sm leading-relaxed text-mute",
						children: "These are community stories already told around Funngro. Totals are reported, not audited here. Copy the habit, not the screenshot."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 md:grid-cols-2",
						children: stories.map((story, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: index === 0 ? "rounded-card bg-cream p-6 text-ink md:col-span-2" : "rounded-card border border-line bg-ink p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl font-extrabold",
										children: story.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold",
										children: story.city
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-3xl text-base leading-relaxed",
									children: story.quote
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 font-display text-3xl font-extrabold text-coral",
									children: story.figure
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold uppercase tracking-wide opacity-70",
									children: story.note
								})
							]
						}, story.name))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-bold tracking-[0.18em] text-lime uppercase",
					children: "06 — The part brochures skip"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 max-w-2xl font-display text-4xl font-extrabold tracking-tight",
					children: "A lot of the company is run by people who started as users."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						["Support", "First replies and brand onboarding, staffed by young Indians."],
						["Quality", "Community QA and bug bashes before a release ships."],
						["Content", "Social and in-app creative made by the audience itself."],
						["Clans", "About a hundred clan leaders across large earner groups."]
					].map(([title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card border border-line p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-xl font-extrabold",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-mute",
							children: body
						})]
					}, title))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 grid gap-4 md:grid-cols-4",
					children: timeline.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-lime pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-extrabold text-lime",
							children: item.when
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-mute",
							children: item.text
						})]
					}, item.when))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line",
			id: "faq",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-3xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl font-extrabold tracking-tight",
						children: "Questions, answered in public language."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 divide-y divide-line border-y border-line",
						children: earnerFaq.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "group py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
								className: "flex min-h-11 cursor-pointer items-center justify-between gap-4 font-semibold",
								children: [
									item.q,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-lime group-open:hidden",
										children: "+"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden text-lime group-open:inline",
										children: "–"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-mute",
								children: item.a
							})]
						}, item.q))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 text-sm text-mute",
						children: ["Hiring instead? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/companies",
							className: "font-bold text-lime",
							children: "Open the company side."
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "px-5 pb-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl rounded-card bg-lime px-6 py-12 text-ink sm:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "max-w-xl font-display text-4xl font-extrabold tracking-tight sm:text-5xl",
						children: "Enrollment is on Funngro. This page gets you ready."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-lg text-sm leading-relaxed",
						children: "Free to join. OTP, projects, and UPI live in their app. Nothing here takes a payment or a password."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: official.play,
								target: "_blank",
								rel: "noreferrer noopener",
								className: "inline-flex h-12 items-center justify-center rounded-xl bg-ink px-5 text-sm font-bold text-cream",
								children: "Get it on Google Play"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: official.ios,
								target: "_blank",
								rel: "noreferrer noopener",
								className: "inline-flex h-12 items-center justify-center rounded-xl border border-ink/20 px-5 text-sm font-bold",
								children: "App Store"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: official.earn,
								target: "_blank",
								rel: "noreferrer noopener",
								className: "inline-flex h-12 items-center justify-center rounded-xl border border-ink/20 px-5 text-sm font-bold",
								children: "Start on funngro.com"
							})
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setBoardOpen(true),
			className: "fixed bottom-5 left-4 z-40 h-12 rounded-full bg-cream px-4 text-sm font-bold text-ink shadow-lg",
			children: ["My board · ", saved.length]
		}),
		boardOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-50 flex justify-end bg-ink/70",
			onClick: () => setBoardOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				role: "dialog",
				"aria-modal": "true",
				"aria-label": "Pinned projects",
				className: "h-full w-full max-w-md overflow-y-auto bg-cream p-6 text-ink",
				onClick: (event) => event.stopPropagation(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-extrabold",
							children: "Your board"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 px-3 text-sm font-bold",
							onClick: () => setBoardOpen(false),
							children: "Close"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-ink/70",
						children: "Saved only in this browser. Nothing is sent to a company."
					}),
					savedProjects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-sm",
						children: "Pin a project from the studio and it will sit here."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 grid gap-3",
						children: savedProjects.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl bg-cream-dim p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold uppercase tracking-wide text-ink/50",
									children: project.kind
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-display text-xl font-extrabold",
									children: project.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm",
									children: project.payLabel
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mt-3 h-11 text-sm font-bold text-coral",
									onClick: () => toggleSave(project),
									children: "Remove"
								})
							]
						}, project.id))
					})
				]
			})
		}) : null,
		message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			role: "status",
			className: "fixed right-4 bottom-24 z-50 max-w-xs rounded-2xl bg-cream px-4 py-3 text-sm font-bold text-ink shadow-lg",
			children: message
		}) : null
	] });
}
var SplitComponent = TeenHome;
//#endregion
export { SplitComponent as component };
