import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as ExternalLink } from "../_libs/lucide-react.mjs";
import { n as official } from "./router-B7G51j_a.mjs";
import { n as brandFaq, r as brandWorks, s as inr } from "./content-BDpXuANd.mjs";
import { i as ResponsiveContainer, n as XAxis, r as Bar, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/companies-Ptm0KcfZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var cities = [
	"Delhi",
	"Mumbai",
	"Bengaluru",
	"Hyderabad",
	"Pune",
	"Jaipur",
	"Surat",
	"Kolkata"
];
var actionRate = {
	promotion: 40,
	sampling: 120,
	referral: 80,
	content: 450,
	survey: 25,
	influencer: 700,
	testing: 350,
	ideation: 250
};
var proofOptions = [
	{
		id: "shot",
		label: "Screenshot of the live post"
	},
	{
		id: "link",
		label: "A public link that still opens"
	},
	{
		id: "photo",
		label: "A photo taken this week"
	},
	{
		id: "code",
		label: "A survey completion code"
	},
	{
		id: "steps",
		label: "Bug steps someone else can follow"
	}
];
var growth = [
	{
		name: "W1",
		value: 35
	},
	{
		name: "W2",
		value: 48
	},
	{
		name: "W3",
		value: 42
	},
	{
		name: "W4",
		value: 63
	},
	{
		name: "W5",
		value: 58
	},
	{
		name: "W6",
		value: 77
	},
	{
		name: "W7",
		value: 91
	}
];
function CompanyHome() {
	const [goal, setGoal] = (0, import_react.useState)(brandWorks[0]?.id ?? "promotion");
	const [picked, setPicked] = (0, import_react.useState)(["Delhi", "Bengaluru"]);
	const [band, setBand] = (0, import_react.useState)("14–25");
	const [budget, setBudget] = (0, import_react.useState)(5e4);
	const [proofs, setProofs] = (0, import_react.useState)(["shot", "link"]);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [chartOn, setChartOn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setChartOn(true), []);
	const work = brandWorks.find((item) => item.id === goal) ?? brandWorks[0];
	const rate = actionRate[goal] ?? 100;
	const actions = Math.max(1, Math.floor(budget / rate));
	const proofLine = proofOptions.filter((item) => proofs.includes(item.id)).map((item) => item.label).join("; ");
	const brief = (0, import_react.useMemo)(() => {
		const where = picked.length ? picked.join(", ") : "pan-India, remote-first";
		return [
			`Goal: ${work?.name ?? "Brand promotion"}.`,
			`Cohort: young Indians aged ${band} in ${where}.`,
			`Budget frame: ${inr(budget)} for verified actions, not impressions.`,
			`Illustrative yield: about ${actions} actions at ${inr(rate)} each. Funngro prices the live campaign.`,
			`What good looks like: ${work?.line ?? ""}`,
			`Best when: ${work?.goodFor ?? ""}`,
			proofLine ? `Proof we will accept: ${proofLine}.` : "Proof we will accept: still to be defined.",
			"Pay after approval. Do not ask anyone under 14 to do company work."
		].join(" ");
	}, [
		work,
		band,
		picked,
		budget,
		actions,
		rate,
		proofLine
	]);
	const mailHref = `mailto:${official.brandsMail}?subject=${encodeURIComponent("Youth brief — intro from the studio")}&body=${encodeURIComponent(`${brief}\n\nThis is an introduction, not a live campaign. Please reply with how to enroll the brand.`)}`;
	function toggleCity(city) {
		setPicked((current) => current.includes(city) ? current.filter((item) => item !== city) : [...current, city]);
	}
	function toggleProof(id) {
		setProofs((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
	}
	function chooseWork(id) {
		setGoal(id);
		document.getElementById("brief")?.scrollIntoView({ behavior: "smooth" });
	}
	async function copyBrief() {
		try {
			await navigator.clipboard.writeText(brief);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 2e3);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto grid max-w-6xl items-end gap-10 px-5 py-14 lg:grid-cols-[1.1fr_0.9fr] lg:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-[0.18em] text-coral uppercase",
						children: "For companies"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-4 font-display text-5xl leading-[0.95] font-extrabold tracking-tight sm:text-6xl",
						children: ["Reach is cheap.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 block text-lime",
							children: "A finished action is not."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl text-base leading-relaxed text-mute",
						children: "Funngro’s public offer is 70 lakh young Indians who opted in to do something: promote, sample, refer, answer, test, or make the work. Draft the brief here — their site never lets you — then send it to them."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-7 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: official.brands,
							target: "_blank",
							rel: "noreferrer noopener",
							className: "tap inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-lime px-5 text-sm font-bold text-ink",
							children: ["Enroll the brand", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#brief",
							className: "inline-flex h-12 items-center justify-center rounded-xl border border-line px-5 text-sm font-bold",
							children: "Draft a brief first"
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "rounded-card border border-line bg-panel p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold tracking-[0.16em] text-mute uppercase",
							children: "Illustrative month"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-2xl font-extrabold",
							children: "Actions, not a vanity chart"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-36",
							children: chartOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
									data: growth,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "name",
										tick: {
											fill: "var(--color-mute)",
											fontSize: 12
										},
										axisLine: false,
										tickLine: false
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "value",
										fill: "var(--color-lime)",
										radius: [
											4,
											4,
											0,
											0
										]
									})]
								})
							}) : null
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-2 grid grid-cols-3 gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-mute",
									children: "Projects"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-display text-2xl font-extrabold",
									children: "24"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-mute",
									children: "Matched"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-display text-2xl font-extrabold",
									children: "186"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-mute",
									children: "Done"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-display text-2xl font-extrabold",
									children: "94%"
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-mute",
							children: "Sample figures for the layout. Not a live brand account."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-line",
				id: "problem",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-8 px-5 py-16 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-[0.18em] text-lime uppercase",
						children: "The gap"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl font-extrabold tracking-tight",
						children: "Meta sells impressions. You still need someone to try the thing."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 text-sm leading-relaxed text-mute",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Promote it in their own words. Sample it and say what they thought. Refer one friend who would actually install. Fill a survey without mashing buttons. Break a build and write the steps." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Campaigns on Funngro are reviewed before they go live. Their trust page rules out adult content, gambling, and MLM. Safety mail is",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "font-bold text-cream",
								href: `mailto:${official.safetyMail}`,
								children: official.safetyMail
							}),
							"."
						] })]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "work",
				className: "mx-auto max-w-6xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl font-extrabold tracking-tight",
						children: "Eight ways a brief can look."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-sm text-mute",
						children: "Tap one. It loads the builder underneath — the public brand page only describes the categories."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 sm:grid-cols-2",
						children: brandWorks.map((item, index) => {
							const on = item.id === goal;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => chooseWork(item.id),
								className: on ? "tap rounded-card border border-lime bg-panel p-5 text-left" : "tap rounded-card border border-line p-5 text-left hover:border-cream",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-bold text-lime",
										children: ["0", index + 1]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 font-display text-2xl font-extrabold",
										children: item.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-mute",
										children: item.line
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm font-semibold text-cream",
										children: item.goodFor
									})
								]
							}, item.id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "brief",
				className: "border-y border-line bg-cream text-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-8 px-5 py-16 lg:grid-cols-[0.9fr_1.1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold tracking-[0.18em] uppercase text-ink/50",
							children: "Brief builder"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-4xl font-extrabold tracking-tight",
							children: "Write it here. Send it to Funngro."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm leading-relaxed text-ink/70",
							children: [
								"Nothing is submitted from this page. Copy it, or open a mail to ",
								official.brandsMail,
								", then finish enrollment on their brand page."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-6 block text-sm font-bold",
							htmlFor: "goal",
							children: "Work type"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "goal",
							value: goal,
							onChange: (event) => setGoal(event.target.value),
							className: "mt-2 h-12 w-full rounded-xl border border-ink/15 bg-cream px-3 text-sm font-semibold",
							children: brandWorks.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.id,
								children: item.name
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm font-bold",
							children: "Age band"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [
								"14–17",
								"18–25",
								"14–25"
							].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setBand(option),
								className: band === option ? "h-11 rounded-full bg-ink px-4 text-sm font-bold text-cream" : "h-11 rounded-full border border-ink/15 px-4 text-sm font-bold",
								children: option
							}, option))
						}),
						band !== "18–25" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-ink/70",
							children: "Under 18 needs a parent and age proof. Under 14 is not company work."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm font-bold",
							children: "Cities"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: cities.map((city) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggleCity(city),
								"aria-pressed": picked.includes(city),
								className: picked.includes(city) ? "h-11 rounded-full bg-lime px-4 text-sm font-bold text-ink" : "h-11 rounded-full border border-ink/15 px-4 text-sm font-semibold",
								children: city
							}, city))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 block text-sm font-bold",
							htmlFor: "budget",
							children: ["Budget frame ", inr(budget)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "budget",
							type: "range",
							min: 15e3,
							max: 2e5,
							step: 5e3,
							value: budget,
							onChange: (event) => setBudget(Number(event.target.value))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-semibold",
							children: [
								"About ",
								actions.toLocaleString("en-IN"),
								" verified actions at an illustrative ",
								inr(rate),
								" each."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm font-bold",
							children: "Proof you will accept"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: proofOptions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": proofs.includes(item.id),
								onClick: () => toggleProof(item.id),
								className: proofs.includes(item.id) ? "min-h-11 rounded-full bg-ink px-4 text-sm font-bold text-cream" : "min-h-11 rounded-full border border-ink/15 px-4 text-sm font-semibold",
								children: item.label
							}, item.id))
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card bg-ink p-6 text-cream",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold tracking-[0.16em] text-lime uppercase",
								children: "Sample brief"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-lg leading-relaxed",
								children: brief
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: copyBrief,
										className: "tap h-12 rounded-xl bg-lime px-5 text-sm font-bold text-ink",
										children: copied ? "Copied" : "Copy brief"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: mailHref,
										className: "inline-flex h-12 items-center justify-center rounded-xl border border-line px-5 text-sm font-bold",
										children: ["Email ", official.brandsMail]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: official.brands,
										target: "_blank",
										rel: "noreferrer noopener",
										className: "inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line px-5 text-sm font-bold",
										children: ["Open brand page", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
									})
								]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "process",
				className: "mx-auto max-w-6xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl font-extrabold tracking-tight",
						children: "Five steps. No hiring pipeline."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-8 grid gap-4 md:grid-cols-5",
						children: [
							["Post", "Say the action, the city, the age, and what proof you will accept."],
							["Match", "People who opted into that kind of work see it."],
							["Pick", "Review samples and past approvals. Not follower counts."],
							["Review", "Accept, send back once, or reject with a reason."],
							["Pay", "Approved work is how the wallet on their side gets credited."]
						].map(([title, body], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-card border border-line p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-bold text-coral",
									children: ["0", index + 1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 font-display text-xl font-extrabold",
									children: title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-mute",
									children: body
								})
							]
						}, title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: official.brands,
							target: "_blank",
							rel: "noreferrer noopener",
							className: "tap inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-lime px-5 text-sm font-bold text-ink",
							children: ["Continue on Funngro", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "inline-flex h-12 items-center justify-center rounded-xl border border-line px-5 text-sm font-bold",
							children: "See the teen side"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "faq",
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-3xl px-5 py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl font-extrabold tracking-tight",
							children: "Before you brief a minor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 divide-y divide-line border-y border-line",
							children: brandFaq.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								className: "group py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
									className: "flex min-h-11 cursor-pointer items-center justify-between gap-4 font-semibold",
									children: [
										item.q,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lime group-open:hidden",
											children: "+"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden text-lime group-open:inline",
											children: "–"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-mute",
									children: item.a
								})]
							}, item.q))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-8 text-sm text-mute",
							children: [
								"Official brand page:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "font-bold text-lime",
									href: official.brands,
									target: "_blank",
									rel: "noreferrer noopener",
									children: "funngro.com/for-brands"
								})
							]
						})
					]
				})
			})
		]
	});
}
var SplitComponent = CompanyHome;
//#endregion
export { SplitComponent as component };
